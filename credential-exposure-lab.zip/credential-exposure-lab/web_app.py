#!/usr/bin/env python3
"""
Exp 4 — Plaintext Credential Exposure Study: Interactive Wireshark-Style Web Lab
Starts all 7 local loopback servers (HTTP, HTTPS, FTP, Telnet, SSH, SFTP, UDP)
and serves a live interactive packet capture + Attacker View workbench on 0.0.0.0:8080.
"""

from __future__ import annotations

import json
import mimetypes
import os
import signal
import sys
import threading
import time
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from lab.analyzer import analyze_protocol_pcap
from lab.capture import capture_protocol_session, detect_capture_capability
from lab.clients import CLIENT_RUNNERS
from lab.config import (
    BASE_DIR,
    CAPTURES_DIR,
    COMPARISON_PAIRS,
    DEFAULT_PASSWORD,
    DEFAULT_USERNAME,
    PROTOCOL_ORDER,
    PROTOCOLS,
    STATIC_DIR,
    WEB_HOST,
    WEB_PORT,
)
from lab.servers import LabServerManager

CAPTURE_LOCK = threading.Lock()
SERVER_MANAGER = LabServerManager()
LAST_TESTED = {
    "username": DEFAULT_USERNAME,
    "password": DEFAULT_PASSWORD,
    "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
}
ANALYSIS_CACHE: dict[str, dict] = {}


def refresh_cache(proto_id: str, username: str | None = None, password: str | None = None) -> dict:
    u = username if username is not None else LAST_TESTED["username"]
    p = password if password is not None else LAST_TESTED["password"]
    data = analyze_protocol_pcap(proto_id, expected_username=u, expected_password=p)
    ANALYSIS_CACHE[proto_id] = data
    return data


def get_cached_analysis(proto_id: str) -> dict:
    if proto_id not in ANALYSIS_CACHE:
        return refresh_cache(proto_id)
    return ANALYSIS_CACHE[proto_id]


def build_overview() -> dict:
    items = {}
    for pid in PROTOCOL_ORDER:
        full = get_cached_analysis(pid)
        av = full["attacker_view"]
        summary = full["pcap"].get("summary", {})
        items[pid] = {
            "protocol": full["protocol"],
            "captured": full["captured"],
            "pcap_file": full["protocol"]["pcap_file"],
            "pcap_size_bytes": full["pcap"].get("pcap_size_bytes", 0),
            "summary": summary,
            "attacker_view": av,
        }
    return {
        "order": PROTOCOL_ORDER,
        "pairs": COMPARISON_PAIRS,
        "last_tested": LAST_TESTED,
        "protocols": items,
    }


class ReusableWebServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


class LabWebHandler(BaseHTTPRequestHandler):
    server_version = "Exp4-CredentialLab/1.0"
    sys_version = ""

    def log_message(self, fmt, *args):
        sys.stdout.write(f"[WEB] {self.address_string()} - {fmt % args}\n")
        sys.stdout.flush()

    def _send_json(self, payload: dict, status: int = 200):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, path: Path, content_type: str | None = None, download_name: str | None = None):
        if not path.exists() or not path.is_file():
            self._send_json({"error": "File not found"}, status=404)
            return
        data = path.read_bytes()
        ctype = content_type or mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        if download_name:
            self.send_header("Content-Disposition", f'attachment; filename="{download_name}"')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/" or path == "/index.html":
            self._send_file(STATIC_DIR / "index.html", "text/html; charset=utf-8")
            return

        if path.startswith("/static/"):
            rel = path[len("/static/") :]
            safe = (STATIC_DIR / rel).resolve()
            if STATIC_DIR.resolve() not in safe.parents and safe != STATIC_DIR.resolve():
                self._send_json({"error": "Forbidden"}, status=403)
                return
            self._send_file(safe)
            return

        if path == "/api/status":
            self._send_json(
                {
                    "servers": SERVER_MANAGER.status(),
                    "capture_capability": detect_capture_capability(),
                    "last_tested": LAST_TESTED,
                    "protocols": PROTOCOLS,
                    "order": PROTOCOL_ORDER,
                    "pairs": COMPARISON_PAIRS,
                }
            )
            return

        if path == "/api/overview":
            self._send_json(build_overview())
            return

        if path.startswith("/api/protocol/"):
            proto_id = path[len("/api/protocol/") :].strip("/")
            if proto_id not in PROTOCOLS:
                self._send_json({"error": f"Unknown protocol: {proto_id}"}, status=404)
                return
            self._send_json(get_cached_analysis(proto_id))
            return

        if path.startswith("/api/pcap/"):
            proto_id = path[len("/api/pcap/") :].strip("/").replace(".pcap", "")
            if proto_id not in PROTOCOLS:
                self._send_json({"error": f"Unknown protocol: {proto_id}"}, status=404)
                return
            fname = PROTOCOLS[proto_id]["pcap_file"]
            self._send_file(
                CAPTURES_DIR / fname,
                content_type="application/vnd.tcpdump.pcap",
                download_name=fname,
            )
            return

        if path == "/api/report":
            report_path = BASE_DIR / "LAB_REPORT.md"
            content = report_path.read_text(encoding="utf-8") if report_path.exists() else ""
            self._send_json({"markdown": content, "overview": build_overview()})
            return

        self._send_json({"error": "Not found"}, status=404)

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path != "/api/capture":
            self._send_json({"error": "Not found"}, status=404)
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            raw_body = self.rfile.read(length).decode("utf-8") if length > 0 else "{}"
            body = json.loads(raw_body)
        except Exception as exc:
            self._send_json({"error": f"Invalid JSON body: {exc}"}, status=400)
            return

        proto_req = str(body.get("protocol", "all")).strip().lower()
        username = str(body.get("username", DEFAULT_USERNAME)).strip() or DEFAULT_USERNAME
        password = str(body.get("password", DEFAULT_PASSWORD)).strip() or DEFAULT_PASSWORD

        # Guard reasonable input lengths for clean lab packets
        username = username[:48]
        password = password[:64]

        targets = PROTOCOL_ORDER if proto_req == "all" else [proto_req]
        for t in targets:
            if t not in PROTOCOLS:
                self._send_json({"error": f"Unknown protocol: {t}"}, status=400)
                return

        cap_info = detect_capture_capability()
        if not cap_info["live_capture_available"]:
            self._send_json(
                {
                    "error": "Live tcpdump/raw capture requires root or sudo privileges. Showing pre-captured .pcap files.",
                    "capture_capability": cap_info,
                },
                status=403,
            )
            return

        run_results = {}
        with CAPTURE_LOCK:
            if not SERVER_MANAGER.running:
                SERVER_MANAGER.start_all()
                time.sleep(0.2)

            LAST_TESTED["username"] = username
            LAST_TESTED["password"] = password
            LAST_TESTED["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S")

            for pid in targets:
                try:
                    cap_meta = capture_protocol_session(
                        pid,
                        lambda p=pid, u=username, pw=password: CLIENT_RUNNERS[p](u, pw),
                    )
                    analysis = refresh_cache(pid, username=username, password=password)
                    run_results[pid] = {
                        "ok": True,
                        "capture_meta": cap_meta,
                        "packet_count": analysis["pcap"].get("summary", {}).get("packet_count", 0),
                        "verdict": analysis["attacker_view"]["verdict"],
                        "credentials_exposed": analysis["attacker_view"]["credentials_exposed"],
                        "entropy": analysis["attacker_view"]["entropy_bits_per_byte"],
                    }
                except Exception as exc:
                    run_results[pid] = {"ok": False, "error": str(exc)}

        self._send_json(
            {
                "ok": all(v.get("ok") for v in run_results.values()),
                "username": username,
                "results": run_results,
                "overview": build_overview(),
            }
        )


def main():
    port = int(os.environ.get("PORT", str(WEB_PORT)))
    print(f"[INIT] Starting all 7 local loopback lab servers on 127.0.0.1...")
    statuses = SERVER_MANAGER.start_all()
    print("[INIT] Lab servers:", ", ".join(f"{k}={v}" for k, v in statuses.items()))
    cap = detect_capture_capability()
    print(f"[INIT] Packet capture capability: {cap['method']} (live={cap['live_capture_available']})")

    # Pre-warm analysis cache from existing captures/*.pcap
    for pid in PROTOCOL_ORDER:
        refresh_cache(pid)

    httpd = ReusableWebServer((WEB_HOST, port), LabWebHandler)

    def _shutdown(signum, frame):
        print("\n[EXIT] Shutting down lab web server & loopback servers...")
        threading.Thread(target=httpd.shutdown, daemon=True).start()
        SERVER_MANAGER.stop_all()

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    print(f"[READY] Exp 4 Credential Exposure Lab running at http://{WEB_HOST}:{port}")
    sys.stdout.flush()
    httpd.serve_forever()


if __name__ == "__main__":
    main()
