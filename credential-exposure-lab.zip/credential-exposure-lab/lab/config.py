"""Central configuration, port mappings, and Wireshark/tcpdump lab metadata."""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
CAPTURES_DIR = BASE_DIR / "captures"
CERTS_DIR = BASE_DIR / "certs"
STATIC_DIR = BASE_DIR / "static"

LOOPBACK_HOST = "127.0.0.1"
WEB_HOST = "0.0.0.0"
WEB_PORT = 8080

DEFAULT_USERNAME = "lab_alice"
DEFAULT_PASSWORD = "CampusLab#2026"

PORTS = {
    "http": 18080,
    "https": 18443,
    "ftp": 12121,
    "ftp_data": 12122,
    "telnet": 12323,
    "ssh": 12222,
    "sftp": 12223,
    "udp_demo": 15140,
}

# Standard well-known ports for educational reference
STANDARD_PORTS = {
    "http": 80,
    "https": 443,
    "ftp": 21,
    "telnet": 23,
    "ssh": 22,
    "sftp": 22,
    "udp_demo": 514,
}

PROTOCOLS = {
    "http": {
        "id": "http",
        "name": "HTTP",
        "full_name": "Hypertext Transfer Protocol (Plaintext)",
        "category": "plaintext",
        "pair": "https",
        "transport": "TCP",
        "lab_port": PORTS["http"],
        "standard_port": 80,
        "bpf_filter": f"tcp port {PORTS['http']}",
        "pcap_file": "http.pcap",
        "tcpdump_cmd": f"sudo tcpdump -i lo -nn -A 'tcp port {PORTS['http']}'",
        "wireshark_filter": f"tcp.port == {PORTS['http']} && http",
        "wireshark_cred_filter": 'http.request.method == "POST" || http.authorization',
        "summary": "Sends HTML form credentials (POST body), Basic Auth (Base64-encoded), and session cookies in cleartext over TCP.",
        "attacker_risk": "CRITICAL — Full plaintext password, decoded Basic Auth header, session cookie, and response body immediately visible.",
        "mitigation": "Enforce HTTPS (TLS 1.3), HSTS headers, Secure/HttpOnly cookies, and disable plaintext port 80 logins.",
    },
    "https": {
        "id": "https",
        "name": "HTTPS",
        "full_name": "HTTP over TLS 1.3 / 1.2 (Encrypted)",
        "category": "encrypted",
        "pair": "http",
        "transport": "TCP",
        "lab_port": PORTS["https"],
        "standard_port": 443,
        "bpf_filter": f"tcp port {PORTS['https']}",
        "pcap_file": "https.pcap",
        "tcpdump_cmd": f"sudo tcpdump -i lo -nn -X 'tcp port {PORTS['https']}'",
        "wireshark_filter": f"tcp.port == {PORTS['https']} && tls",
        "wireshark_cred_filter": "tls.handshake.type == 1 || tls.app_data",
        "summary": "Wraps HTTP inside a TLS session using X.509 certificates and authenticated encryption (AEAD).",
        "attacker_risk": "LOW — Credentials, URL path, headers, cookies, and response body are encrypted. Only TCP metadata + TLS ClientHello SNI & cipher list are visible.",
        "mitigation": "Use TLS 1.3 with strong AEAD ciphers (AES-256-GCM / ChaCha20-Poly1305), valid CA certs, and ECH to minimize SNI metadata.",
    },
    "ftp": {
        "id": "ftp",
        "name": "FTP",
        "full_name": "File Transfer Protocol (RFC 959 Plaintext)",
        "category": "plaintext",
        "pair": "sftp",
        "transport": "TCP",
        "lab_port": PORTS["ftp"],
        "data_port": PORTS["ftp_data"],
        "standard_port": 21,
        "bpf_filter": f"tcp port {PORTS['ftp']} or tcp port {PORTS['ftp_data']}",
        "pcap_file": "ftp.pcap",
        "tcpdump_cmd": f"sudo tcpdump -i lo -nn -A 'tcp port {PORTS['ftp']} or tcp port {PORTS['ftp_data']}'",
        "wireshark_filter": f"tcp.port == {PORTS['ftp']} || tcp.port == {PORTS['ftp_data']}",
        "wireshark_cred_filter": 'ftp.request.command == "USER" || ftp.request.command == "PASS"',
        "summary": "Sends USER and PASS commands in ASCII cleartext over the control channel AND transfers files unencrypted on the PASV data channel.",
        "attacker_risk": "CRITICAL — Both USER/PASS credentials and the entire downloaded file contents are captured verbatim.",
        "mitigation": "Replace legacy FTP with SFTP (SSH File Transfer Protocol) or FTPS (FTP over explicit TLS).",
    },
    "sftp": {
        "id": "sftp",
        "name": "SFTP",
        "full_name": "SSH File Transfer Protocol (Encrypted Subsystem)",
        "category": "encrypted",
        "pair": "ftp",
        "transport": "TCP",
        "lab_port": PORTS["sftp"],
        "standard_port": 22,
        "bpf_filter": f"tcp port {PORTS['sftp']}",
        "pcap_file": "sftp.pcap",
        "tcpdump_cmd": f"sudo tcpdump -i lo -nn -X 'tcp port {PORTS['sftp']}'",
        "wireshark_filter": f"tcp.port == {PORTS['sftp']} && ssh",
        "wireshark_cred_filter": "ssh.protocol || ssh.message_code == 20",
        "summary": "Runs file transfer as a subsystem inside an encrypted SSH-2.0 tunnel — single TCP port, zero separate plaintext data channel.",
        "attacker_risk": "LOW — Authentication, filenames, and transferred file contents are fully encrypted. Only SSH version banner & KEX algorithms are visible.",
        "mitigation": "Prefer SSH key-based auth (Ed25519), disable password auth where possible, and verify host key fingerprints.",
    },
    "telnet": {
        "id": "telnet",
        "name": "Telnet",
        "full_name": "Telnet Remote Terminal (RFC 854 Plaintext)",
        "category": "plaintext",
        "pair": "ssh",
        "transport": "TCP",
        "lab_port": PORTS["telnet"],
        "standard_port": 23,
        "bpf_filter": f"tcp port {PORTS['telnet']}",
        "pcap_file": "telnet.pcap",
        "tcpdump_cmd": f"sudo tcpdump -i lo -nn -A 'tcp port {PORTS['telnet']}'",
        "wireshark_filter": f"tcp.port == {PORTS['telnet']} || telnet",
        "wireshark_cred_filter": "telnet.data",
        "summary": "Transmits every interactive keystroke (username, password, shell commands, and command output) in plaintext — often 1 character per TCP packet.",
        "attacker_risk": "CRITICAL — Even though passwords are not echoed back on screen, client->server packets leak every single keystroke plus all shell commands.",
        "mitigation": "Decommission Telnet completely on all routers, switches, and servers; migrate all remote administration to SSH-2.0.",
    },
    "ssh": {
        "id": "ssh",
        "name": "SSH",
        "full_name": "Secure Shell v2.0 (Encrypted Terminal)",
        "category": "encrypted",
        "pair": "telnet",
        "transport": "TCP",
        "lab_port": PORTS["ssh"],
        "standard_port": 22,
        "bpf_filter": f"tcp port {PORTS['ssh']}",
        "pcap_file": "ssh.pcap",
        "tcpdump_cmd": f"sudo tcpdump -i lo -nn -X 'tcp port {PORTS['ssh']}'",
        "wireshark_filter": f"tcp.port == {PORTS['ssh']} && ssh",
        "wireshark_cred_filter": "ssh.protocol || ssh.message_code == 20",
        "summary": "Performs Diffie-Hellman / Curve25519 key exchange before userauth, encrypting passwords, keystrokes, and shell output end-to-end.",
        "attacker_risk": "LOW — Passwords, commands, and terminal output are high-entropy ciphertext. Only SSH-2.0 software banners & KEXINIT algorithm lists appear in cleartext.",
        "mitigation": "Use SSHv2 only, Ed25519 keys, strong KEX/AEAD ciphers, and fail2ban/rate-limiting.",
    },
    "udp_demo": {
        "id": "udp_demo",
        "name": "UDP Auth/Syslog",
        "full_name": "UDP Datagram Login / Syslog (TCP vs UDP Comparison)",
        "category": "plaintext",
        "pair": None,
        "transport": "UDP",
        "lab_port": PORTS["udp_demo"],
        "standard_port": 514,
        "bpf_filter": f"udp port {PORTS['udp_demo']}",
        "pcap_file": "udp_demo.pcap",
        "tcpdump_cmd": f"sudo tcpdump -i lo -nn -A 'udp port {PORTS['udp_demo']}'",
        "wireshark_filter": f"udp.port == {PORTS['udp_demo']}",
        "wireshark_cred_filter": f"udp.port == {PORTS['udp_demo']} && frame contains \"pass=\"",
        "summary": "Demonstrates connectionless UDP (8-byte header, no 3-way handshake, no Seq/Ack) sending unencrypted auth telemetry vs TCP's stateful stream.",
        "attacker_risk": "CRITICAL — Credentials leak in a single 1-packet UDP datagram without even establishing a handshake.",
        "mitigation": "Encrypt UDP protocols with DTLS, QUIC, or WireGuard/IPsec; never send cleartext tokens over raw UDP.",
    },
}

PROTOCOL_ORDER = ["http", "https", "ftp", "sftp", "telnet", "ssh", "udp_demo"]

COMPARISON_PAIRS = [
    {
        "id": "web",
        "title": "Web Login: HTTP vs HTTPS",
        "insecure": "http",
        "secure": "https",
        "use_case": "Web portals, REST APIs, Form & Basic Authentication",
    },
    {
        "id": "file",
        "title": "File Transfer: FTP vs SFTP",
        "insecure": "ftp",
        "secure": "sftp",
        "use_case": "Uploading & downloading files with server credentials",
    },
    {
        "id": "shell",
        "title": "Remote Shell: Telnet vs SSH",
        "insecure": "telnet",
        "secure": "ssh",
        "use_case": "Interactive terminal login & remote command execution",
    },
]
