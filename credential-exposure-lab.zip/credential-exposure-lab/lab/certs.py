"""Generates real lab TLS X.509 certificates and SSH host keys on localhost."""

import subprocess
from pathlib import Path
from .config import CERTS_DIR


def ensure_tls_cert() -> tuple[Path, Path]:
    """Generate a self-signed RSA-2048 TLS certificate for lab-portal.local if absent."""
    CERTS_DIR.mkdir(parents=True, exist_ok=True)
    cert_path = CERTS_DIR / "lab_https.crt"
    key_path = CERTS_DIR / "lab_https.key"

    if cert_path.exists() and key_path.exists():
        return cert_path, key_path

    cmd = [
        "openssl",
        "req",
        "-x509",
        "-newkey",
        "rsa:2048",
        "-keyout",
        str(key_path),
        "-out",
        str(cert_path),
        "-days",
        "365",
        "-nodes",
        "-subj",
        "/C=IN/ST=Rajasthan/L=Jaipur/O=Exp4-Security-Lab/CN=lab-portal.local",
        "-addext",
        "subjectAltName=DNS:lab-portal.local,IP:127.0.0.1",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"Failed to generate TLS cert with openssl: {result.stderr}")
    return cert_path, key_path


def ensure_ssh_host_key() -> Path:
    """Generate an RSA-2048 SSH host key for the local SSH/SFTP lab servers."""
    CERTS_DIR.mkdir(parents=True, exist_ok=True)
    key_path = CERTS_DIR / "ssh_host_rsa_key"
    if key_path.exists():
        return key_path

    try:
        import paramiko

        key = paramiko.RSAKey.generate(2048)
        key.write_private_key_file(str(key_path))
        return key_path
    except Exception:
        # Fallback to ssh-keygen if paramiko isn't installed
        result = subprocess.run(
            ["ssh-keygen", "-t", "rsa", "-b", "2048", "-N", "", "-m", "PEM", "-f", str(key_path)],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(f"Failed to generate SSH host key: {result.stderr}")
        return key_path
