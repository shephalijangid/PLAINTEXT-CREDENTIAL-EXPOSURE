"""
Plaintext Credential Exposure Study — Exp 4 (Wireshark / tcpdump, TCP & UDP)
Local loopback lab capturing real logins over HTTP, FTP, Telnet vs HTTPS, SFTP, SSH (+ UDP).
"""
