"""
Passive Network Attacker View Analyzer.
Inspects ONLY captured .pcap files to show:
  1. Extracted plaintext credentials, decoded Basic Auth, cookies, commands, and transferred files.
  2. Quantitative Shannon entropy (bits/byte) comparing plaintext vs ciphertext payloads.
  3. Metadata still visible to an attacker even under TLS/SSH encryption (IPs, ports, SNI, SSH banners, KEX).
  4. Exact packet frame numbers carrying sensitive material (for Wireshark-style row highlighting).
"""

from __future__ import annotations

import base64
import math
import re
import urllib.parse
from collections import Counter
from pathlib import Path
from typing import Any, Optional

from .capture import get_tcpdump_text
from .config import CAPTURES_DIR, PROTOCOLS
from .pcap_parser import parse_pcap


def shannon_entropy(data: bytes) -> float:
    """Compute Shannon entropy in bits per byte (0.0 = constant, 8.0 = uniform random/encrypted)."""
    if not data:
        return 0.0
    counts = Counter(data)
    total = len(data)
    ent = 0.0
    for c in counts.values():
        p = c / total
        ent -= p * math.log2(p)
    return round(ent, 3)


def _strip_telnet_iac(raw: bytes) -> str:
    out = []
    i = 0
    while i < len(raw):
        if raw[i] == 255 and i + 2 < len(raw):
            i += 3
            continue
        b = raw[i]
        if b in (10, 13) or 32 <= b <= 126:
            out.append(chr(b))
        i += 1
    return "".join(out)


def _collect_raw_payload_bytes(pcap_path: Path, parsed: dict[str, Any], protocol_id: str) -> tuple[bytes, bytes]:
    """
    Re-extract raw application payload bytes (all_app_bytes, encrypted_only_bytes)
    by scanning the parsed streams' hex/raw data directly from the pcap file.
    """
    if not pcap_path.exists():
        return b"", b""
    raw = pcap_path.read_bytes()
    if len(raw) < 24:
        return b"", b""

    magic = raw[0:4]
    endian = "<" if magic in (b"\xd4\xc3\xb2\xa1", b"\x4d\x3c\xb2\xa1") else ">"
    linktype = int.from_bytes(raw[20:24], "little" if endian == "<" else "big")
    l2_len = 14 if linktype == 1 else (16 if linktype == 113 else 4)

    all_payload = bytearray()
    encrypted_payload = bytearray()
    pkt_payloads: dict[int, bytes] = {}

    offset = 24
    frame_no = 0
    while offset + 16 <= len(raw):
        incl_len = int.from_bytes(raw[offset + 8 : offset + 12], "little" if endian == "<" else "big")
        offset += 16
        frame = raw[offset : offset + incl_len]
        offset += incl_len
        frame_no += 1
        if len(frame) < l2_len + 20:
            continue
        ihl = (frame[l2_len] & 0x0F) * 4
        ip_tot = int.from_bytes(frame[l2_len + 2 : l2_len + 4], "big")
        proto = frame[l2_len + 9]
        l4_off = l2_len + ihl
        ip_end = min(len(frame), l2_len + ip_tot)
        payload = b""
        if proto == 6 and len(frame) >= l4_off + 20:
            tcp_hdr = ((frame[l4_off + 12] >> 4) & 0xF) * 4
            payload = frame[l4_off + tcp_hdr : ip_end]
        elif proto == 17 and len(frame) >= l4_off + 8:
            payload = frame[l4_off + 8 : ip_end]

        if payload:
            pkt_payloads[frame_no] = payload
            all_payload.extend(payload)

    # Identify strictly post-handshake encrypted payload segments for TLS / SSH / SFTP
    for p in parsed.get("packets", []):
        fn = p["no"]
        pl = pkt_payloads.get(fn, b"")
        if not pl:
            continue
        app = p["layers"].get("application", {})
        if protocol_id == "https":
            recs = app.get("records", [])
            if any(r.get("content_type") == "Application Data" for r in recs) or app.get("encrypted"):
                encrypted_payload.extend(pl)
        elif protocol_id in ("ssh", "sftp"):
            if app.get("encrypted"):
                encrypted_payload.extend(pl)

    return bytes(all_payload), bytes(encrypted_payload), pkt_payloads


def analyze_protocol_pcap(
    protocol_id: str,
    pcap_path: Optional[Path] = None,
    expected_username: Optional[str] = None,
    expected_password: Optional[str] = None,
) -> dict[str, Any]:
    """Parse a captured .pcap and construct the complete Attacker View report."""
    meta = PROTOCOLS[protocol_id]
    path = pcap_path or (CAPTURES_DIR / meta["pcap_file"])
    parsed = parse_pcap(path, protocol_id)
    if not parsed.get("exists") or not parsed.get("packets"):
        return {
            "protocol": meta,
            "captured": False,
            "pcap": parsed,
            "attacker_view": {
                "verdict": "NOT_CAPTURED",
                "credentials_exposed": False,
                "extracted": [],
                "visible_metadata": [],
                "entropy_bits_per_byte": 0.0,
            },
            "tcpdump_summary": "",
            "tcpdump_hex": "",
        }

    all_payload, enc_payload, pkt_payloads = _collect_raw_payload_bytes(path, parsed, protocol_id)
    raw_pcap_bytes = path.read_bytes()

    extracted: list[dict[str, Any]] = []
    visible_metadata: list[dict[str, str]] = []
    exposed_frames: set[int] = set()
    metadata_frames: set[int] = set()

    packets = parsed["packets"]
    # General L3/L4 metadata always visible to ANY passive sniffer
    endpoints = sorted({(p["src"], p["dst"]) for p in packets})
    first_pkt = packets[0]
    visible_metadata.append(
        {
            "item": "Network Endpoints (IP & Ports)",
            "value": f"{first_pkt['src']} <-> {first_pkt['dst']}",
            "why": "IPv4 & TCP/UDP headers are NEVER encrypted by TLS or SSH (needed for routing).",
        }
    )
    visible_metadata.append(
        {
            "item": "Traffic Profile (Size & Timing)",
            "value": f"{parsed['summary']['packet_count']} packets, {parsed['summary']['total_wire_bytes']} bytes over {parsed['summary']['duration_sec']:.3f}s",
            "why": "Packet counts, burst timing, and payload sizes remain visible to passive observers.",
        }
    )

    # --- Protocol-specific passive extraction ---
    if protocol_id == "http":
        for p in packets:
            app = p["layers"].get("application", {})
            body = app.get("body", "")
            headers = app.get("headers", {})
            if "username=" in body or "password=" in body:
                qs = urllib.parse.parse_qs(body)
                u = qs.get("username", [""])[0]
                pw = qs.get("password", [""])[0]
                extracted.append(
                    {
                        "type": "HTTP Form POST Credentials",
                        "frame": p["no"],
                        "username": u,
                        "password": pw,
                        "raw_evidence": body,
                    }
                )
                exposed_frames.add(p["no"])
            if "decoded_basic_auth" in app:
                raw_auth = headers.get("Authorization", "")
                u, _, pw = app["decoded_basic_auth"].partition(":")
                extracted.append(
                    {
                        "type": "HTTP Basic Auth (Base64 Decoded)",
                        "frame": p["no"],
                        "username": u,
                        "password": pw,
                        "raw_evidence": f"{raw_auth}  ==>  {app['decoded_basic_auth']}",
                    }
                )
                exposed_frames.add(p["no"])
            if "Set-Cookie" in headers:
                extracted.append(
                    {
                        "type": "Session Cookie Hijack Token",
                        "frame": p["no"],
                        "username": "",
                        "password": "",
                        "raw_evidence": f"Set-Cookie: {headers['Set-Cookie']}",
                    }
                )
                exposed_frames.add(p["no"])

    elif protocol_id == "ftp":
        found_user = None
        user_frame = None
        for p in packets:
            app = p["layers"].get("application", {})
            line = app.get("line", "").strip()
            if line.upper().startswith("USER "):
                found_user = line[5:].strip()
                user_frame = p["no"]
                exposed_frames.add(p["no"])
            elif line.upper().startswith("PASS "):
                pw = line[5:].strip()
                exposed_frames.add(p["no"])
                extracted.append(
                    {
                        "type": "FTP Control Channel Login (USER / PASS)",
                        "frame": p["no"],
                        "username": found_user or "",
                        "password": pw,
                        "raw_evidence": f"Frame #{user_frame}: USER {found_user} | Frame #{p['no']}: PASS {pw}",
                    }
                )
            elif app.get("channel") == "PASV data" and app.get("plaintext_file"):
                exposed_frames.add(p["no"])
                extracted.append(
                    {
                        "type": "FTP Passive Data Channel File Exfiltration",
                        "frame": p["no"],
                        "username": "",
                        "password": "",
                        "raw_evidence": app["plaintext_file"].strip()[:220],
                    }
                )

    elif protocol_id == "telnet":
        # Reconstruct client->server and server->client keystroke stream chronologically
        c2s_lines: list[tuple[int, str]] = []
        cur_chars: list[str] = []
        cur_frames: list[int] = []
        for p in packets:
            pl = pkt_payloads.get(p["no"], b"")
            if not pl:
                continue
            if p["direction"] == "client->server":
                txt = _strip_telnet_iac(pl)
                for ch in txt:
                    if ch in ("\r", "\n"):
                        if cur_chars:
                            c2s_lines.append((cur_frames[0], "".join(cur_chars)))
                            for f in cur_frames:
                                exposed_frames.add(f)
                            cur_chars = []
                            cur_frames = []
                    else:
                        cur_chars.append(ch)
                        cur_frames.append(p["no"])
            else:
                txt = _strip_telnet_iac(pl)
                if "LAB_SECRET_FLAG" in txt:
                    exposed_frames.add(p["no"])
                    extracted.append(
                        {
                            "type": "Telnet Command Output (Leaked Secret File)",
                            "frame": p["no"],
                            "username": "",
                            "password": "",
                            "raw_evidence": txt.strip()[:200],
                        }
                    )

        if cur_chars:
            c2s_lines.append((cur_frames[0], "".join(cur_chars)))

        # First typed line = username, second typed line = password, rest = shell commands
        t_user = c2s_lines[0][1] if len(c2s_lines) >= 1 else ""
        t_pass = c2s_lines[1][1] if len(c2s_lines) >= 2 else ""
        t_cmds = [ln for _, ln in c2s_lines[2:]]
        if t_user or t_pass:
            extracted.insert(
                0,
                {
                    "type": "Telnet Interactive Keystroke Reassembly",
                    "frame": c2s_lines[0][0],
                    "username": t_user,
                    "password": t_pass,
                    "raw_evidence": f"Reassembled 1-char-per-packet stream -> login: {t_user} | Password: {t_pass} (un-echoed on screen yet 100% visible on wire!)",
                },
            )
        if t_cmds:
            extracted.append(
                {
                    "type": "Telnet Interactive Shell Commands Captured",
                    "frame": c2s_lines[2][0],
                    "username": "",
                    "password": "",
                    "raw_evidence": " ; ".join(t_cmds),
                }
            )

    elif protocol_id == "udp_demo":
        for p in packets:
            app = p["layers"].get("application", {})
            txt = app.get("datagram_text", "")
            if "AUTH_OK" in txt:
                exposed_frames.add(p["no"])
                extracted.append(
                    {
                        "type": "UDP Cleartext Session Token Reply",
                        "frame": p["no"],
                        "username": "",
                        "password": "",
                        "raw_evidence": txt,
                    }
                )
            elif "user=" in txt or "pass=" in txt:
                u_m = re.search(r"user=([^\s]+)", txt)
                p_m = re.search(r"pass=([^\s]+)", txt)
                exposed_frames.add(p["no"])
                extracted.append(
                    {
                        "type": "UDP Single-Datagram Cleartext Credentials",
                        "frame": p["no"],
                        "username": u_m.group(1) if u_m else "",
                        "password": p_m.group(1) if p_m else "",
                        "raw_evidence": txt,
                    }
                )

    elif protocol_id == "https":
        for p in packets:
            app = p["layers"].get("application", {})
            if app.get("sni"):
                metadata_frames.add(p["no"])
                visible_metadata.append(
                    {
                        "item": "TLS ClientHello SNI (Server Name Indication)",
                        "value": app["sni"],
                        "why": "Sent in plaintext during TLS handshake so reverse proxies know which cert to serve (unless ECH is enabled).",
                    }
                )
            if app.get("negotiated_version") or app.get("selected_cipher"):
                metadata_frames.add(p["no"])
                visible_metadata.append(
                    {
                        "item": "TLS Handshake Parameters",
                        "value": f"{app.get('negotiated_version', 'TLS')} / {app.get('selected_cipher', 'AEAD')}",
                        "why": "Negotiated TLS version and cipher suite appear in ServerHello before encrypted Application Data.",
                    }
                )

    elif protocol_id in ("ssh", "sftp"):
        banners = []
        kex_seen = False
        for p in packets:
            app = p["layers"].get("application", {})
            if app.get("banner"):
                metadata_frames.add(p["no"])
                banners.append(f"{p['direction']}: {app['banner']}")
            if app.get("message_name") == "SSH_MSG_KEXINIT" and not kex_seen:
                kex_seen = True
                metadata_frames.add(p["no"])
                ciphers = ", ".join(app.get("encryption_c2s", [])[:3])
                kex = ", ".join(app.get("kex_algorithms", [])[:2])
                visible_metadata.append(
                    {
                        "item": "SSH_MSG_KEXINIT Algorithm Proposal",
                        "value": f"KEX: {kex} | Ciphers: {ciphers}",
                        "why": "Key-exchange negotiation happens in plaintext prior to SSH_MSG_NEWKEYS.",
                    }
                )
        if banners:
            visible_metadata.append(
                {
                    "item": "SSH Protocol Identification Banners",
                    "value": " | ".join(banners[:2]),
                    "why": "RFC 4253 exchanges software version strings in plaintext before key exchange.",
                }
            )

    # Mark frames in parsed packets for UI color-coding
    for p in packets:
        p["leaks_credential"] = p["no"] in exposed_frames
        p["plaintext_metadata"] = p["no"] in metadata_frames

    # Byte-level literal verification against raw .pcap file (when expected creds provided)
    raw_secret_check: dict[str, Any] = {}
    if expected_username or expected_password:
        u_str = expected_username or ""
        p_str = expected_password or ""
        u_variants = [u_str.encode("utf-8"), urllib.parse.quote_plus(u_str).encode("utf-8")] if u_str else []
        p_variants = [
            p_str.encode("utf-8"),
            urllib.parse.quote_plus(p_str).encode("utf-8"),
            urllib.parse.quote(p_str, safe="").encode("utf-8"),
        ] if p_str else []
        b64_bytes = base64.b64encode(f"{u_str}:{p_str}".encode("utf-8"))
        # For telnet, credentials arrive 1 byte per packet so also check reassembled client->server stream
        c2s_stream_bytes = b"".join(
            pkt_payloads.get(p["no"], b"") for p in packets if p["direction"] == "client->server"
        )
        u_in_wire = any(v and (v in raw_pcap_bytes or v in c2s_stream_bytes) for v in u_variants)
        b64_in_wire = bool(b64_bytes and b64_bytes in raw_pcap_bytes)
        p_in_wire = any(v and (v in raw_pcap_bytes or v in c2s_stream_bytes) for v in p_variants) or b64_in_wire
        raw_secret_check = {
            "tested_username": expected_username,
            "username_found_in_pcap": u_in_wire,
            "password_found_in_pcap": p_in_wire,
            "base64_auth_found_in_pcap": b64_in_wire,
        }

    is_encrypted_proto = meta["category"] == "encrypted"
    credentials_exposed = len(extracted) > 0
    overall_entropy = shannon_entropy(all_payload)
    ciphertext_entropy = shannon_entropy(enc_payload) if enc_payload else overall_entropy

    # Printable ASCII strings an attacker gets running `strings <file>.pcap` on payload
    ascii_strings = re.findall(rb"[ -~]{6,}", all_payload)
    sample_strings = [s.decode("ascii", errors="replace")[:96] for s in ascii_strings[:12]]

    return {
        "protocol": meta,
        "captured": True,
        "pcap": parsed,
        "attacker_view": {
            "verdict": "EXPOSED — CREDENTIALS CAPTURED" if credentials_exposed else "PROTECTED — ENCRYPTED PAYLOAD",
            "severity": "CRITICAL" if credentials_exposed else "SECURE",
            "credentials_exposed": credentials_exposed,
            "extracted": extracted,
            "visible_metadata": visible_metadata,
            "entropy_bits_per_byte": ciphertext_entropy if is_encrypted_proto else overall_entropy,
            "overall_payload_entropy": overall_entropy,
            "ciphertext_entropy": ciphertext_entropy if is_encrypted_proto else None,
            "attacker_strings_preview": sample_strings,
            "raw_secret_check": raw_secret_check,
            "what_attacker_sees_summary": (
                f"Passive sniffer extracted {len(extracted)} sensitive artifact(s) directly from {path.name} with zero decryption."
                if credentials_exposed
                else f"0 credentials recovered from {len(all_payload)} payload bytes (ciphertext entropy {ciphertext_entropy:.2f}/8.00 bits/byte). Only L3/L4 headers & handshake metadata visible."
            ),
        },
        "tcpdump_summary": get_tcpdump_text(path, hex_ascii=False, max_chars=8000),
        "tcpdump_hex": get_tcpdump_text(path, hex_ascii=True, max_chars=12000),
    }
