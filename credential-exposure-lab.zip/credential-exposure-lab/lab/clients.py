"""
Authentic protocol clients that execute real logins against the local loopback lab servers
while tcpdump captures the actual wire packets on interface `lo`.
"""

from __future__ import annotations

import base64
import ftplib
import http.client
import socket
import ssl
import time
import urllib.parse
from typing import Any

from .certs import ensure_tls_cert
from .config import LOOPBACK_HOST, PORTS


def run_http_login(username: str, password: str) -> dict[str, Any]:
    """Perform both HTML Form POST login and HTTP Basic Auth request over plaintext HTTP."""
    conn = http.client.HTTPConnection(LOOPBACK_HOST, PORTS["http"], timeout=5)
    body = urllib.parse.urlencode(
        {"username": username, "password": password, "remember": "1"}
    )
    conn.request(
        "POST",
        "/login",
        body=body,
        headers={
            "Host": "lab-portal.local",
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "Exp4-LabClient/1.0",
        },
    )
    resp1 = conn.getresponse()
    resp1_body = resp1.read().decode("utf-8", errors="replace")
    cookie = resp1.getheader("Set-Cookie", "")

    b64 = base64.b64encode(f"{username}:{password}".encode("utf-8")).decode("ascii")
    conn.request(
        "GET",
        "/api/profile",
        headers={
            "Host": "lab-portal.local",
            "Authorization": f"Basic {b64}",
            "Cookie": cookie.split(";", 1)[0] if cookie else "",
            "User-Agent": "Exp4-LabClient/1.0",
        },
    )
    resp2 = conn.getresponse()
    resp2_body = resp2.read().decode("utf-8", errors="replace")
    conn.close()
    return {
        "protocol": "http",
        "ok": resp1.status == 200 and resp2.status == 200,
        "steps": [
            f"POST /login -> HTTP {resp1.status}",
            f"GET /api/profile (Basic Auth) -> HTTP {resp2.status}",
        ],
        "response_preview": resp1_body[:200],
    }


def run_https_login(username: str, password: str) -> dict[str, Any]:
    """Perform identical Form POST + Basic Auth requests over real TLS (with SNI lab-portal.local)."""
    cert_path, _ = ensure_tls_cert()
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.load_verify_locations(cafile=str(cert_path))
    ctx.check_hostname = True
    ctx.verify_mode = ssl.CERT_REQUIRED

    raw_sock = socket.create_connection((LOOPBACK_HOST, PORTS["https"]), timeout=5)
    tls_sock = ctx.wrap_socket(raw_sock, server_hostname="lab-portal.local")
    tls_version = tls_sock.version()
    cipher_info = tls_sock.cipher()

    # Send authentic HTTP/1.1 requests over the encrypted TLS socket
    form_body = urllib.parse.urlencode(
        {"username": username, "password": password, "remember": "1"}
    )
    req1 = (
        f"POST /login HTTP/1.1\r\n"
        f"Host: lab-portal.local\r\n"
        f"User-Agent: Exp4-LabClient/1.0\r\n"
        f"Content-Type: application/x-www-form-urlencoded\r\n"
        f"Content-Length: {len(form_body)}\r\n"
        f"Connection: keep-alive\r\n\r\n"
        f"{form_body}"
    ).encode("utf-8")
    tls_sock.sendall(req1)
    resp1_raw = tls_sock.recv(4096).decode("utf-8", errors="replace")

    b64 = base64.b64encode(f"{username}:{password}".encode("utf-8")).decode("ascii")
    req2 = (
        f"GET /api/profile HTTP/1.1\r\n"
        f"Host: lab-portal.local\r\n"
        f"User-Agent: Exp4-LabClient/1.0\r\n"
        f"Authorization: Basic {b64}\r\n"
        f"Connection: close\r\n\r\n"
    ).encode("utf-8")
    tls_sock.sendall(req2)
    resp2_raw = tls_sock.recv(4096).decode("utf-8", errors="replace")
    tls_sock.close()

    return {
        "protocol": "https",
        "ok": "200 OK" in resp1_raw and "200 OK" in resp2_raw,
        "tls_version": tls_version,
        "cipher": cipher_info[0] if cipher_info else "unknown",
        "steps": [
            f"TLS Handshake ({tls_version}, {cipher_info[0] if cipher_info else ''}, SNI=lab-portal.local)",
            "Encrypted POST /login -> 200 OK",
            "Encrypted GET /api/profile (Basic Auth) -> 200 OK",
        ],
    }


def run_ftp_login(username: str, password: str) -> dict[str, Any]:
    """Connect with Python stdlib ftplib.FTP, send USER/PASS, and download confidential.txt via PASV."""
    ftp = ftplib.FTP()
    ftp.connect(LOOPBACK_HOST, PORTS["ftp"], timeout=5)
    ftp.login(user=username, passwd=password)
    pwd = ftp.pwd()
    downloaded = bytearray()
    ftp.retrbinary("RETR confidential.txt", downloaded.extend)
    ftp.quit()
    return {
        "protocol": "ftp",
        "ok": len(downloaded) > 0,
        "pwd": pwd,
        "bytes_transferred": len(downloaded),
        "steps": [
            f"USER {username} / PASS ****** -> 230 Logged in",
            f"PWD -> {pwd}",
            f"PASV + RETR confidential.txt -> {len(downloaded)} bytes (cleartext data channel)",
            "QUIT -> 221 Goodbye",
        ],
    }


def run_telnet_login(username: str, password: str) -> dict[str, Any]:
    """Perform authentic RFC 854 Telnet interactive login sending 1 keystroke per TCP packet."""
    sock = socket.create_connection((LOOPBACK_HOST, PORTS["telnet"]), timeout=5)
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    sock.settimeout(4.0)

    def recv_until(marker: bytes) -> bytes:
        buf = b""
        deadline = time.time() + 3.5
        while time.time() < deadline:
            try:
                chunk = sock.recv(4096)
                if not chunk:
                    break
                buf += chunk
                if marker in buf:
                    break
            except socket.timeout:
                break
        return buf

    def type_chars(text: str, delay: float = 0.008):
        for ch in text:
            sock.sendall(ch.encode("utf-8"))
            time.sleep(delay)
        sock.sendall(b"\r\n")
        time.sleep(0.02)

    # Receive IAC options & login prompt
    banner = recv_until(b"login: ")
    # Reply cleanly with Telnet IAC WONT TERMINAL-TYPE / DO ECHO / DO SGA
    sock.sendall(bytes([255, 252, 24, 255, 253, 1, 255, 253, 3]))
    time.sleep(0.02)

    type_chars(username)
    recv_until(b"Password: ")
    type_chars(password)
    recv_until(b"$ ")

    type_chars("whoami")
    recv_until(b"$ ")
    type_chars("cat /etc/lab-secret.txt")
    secret_resp = recv_until(b"$ ")
    type_chars("exit")
    recv_until(b"closed")
    sock.close()

    return {
        "protocol": "telnet",
        "ok": b"LAB_SECRET_FLAG" in secret_resp or b"login:" in banner,
        "steps": [
            "RFC 854 IAC Option Negotiation (ECHO, SGA, TERMINAL-TYPE)",
            f"Typed username ({len(username)} individual TCP keystroke packets)",
            f"Typed password ({len(password)} individual TCP keystroke packets, un-echoed)",
            "Executed: whoami & cat /etc/lab-secret.txt & exit",
        ],
    }


def run_ssh_login(username: str, password: str) -> dict[str, Any]:
    """Authenticate via real SSH-2.0 (paramiko) and execute remote commands over encrypted channel."""
    import paramiko

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        hostname=LOOPBACK_HOST,
        port=PORTS["ssh"],
        username=username,
        password=password,
        look_for_keys=False,
        allow_agent=False,
        timeout=5,
    )
    transport = client.get_transport()
    cipher = transport.remote_cipher if transport else "unknown"
    stdin, stdout, stderr = client.exec_command("whoami && cat /etc/lab-secret.txt")
    out = stdout.read().decode("utf-8", errors="replace")
    client.close()
    return {
        "protocol": "ssh",
        "ok": "LAB_SECRET_FLAG" in out,
        "cipher": cipher,
        "steps": [
            "SSH-2.0 Banner Exchange & KEXINIT Algorithm Negotiation",
            f"Encrypted userauth (password) using {cipher}",
            "Encrypted exec: whoami && cat /etc/lab-secret.txt",
        ],
    }


def run_sftp_login(username: str, password: str) -> dict[str, Any]:
    """Authenticate via real SSH-2.0 + SFTP v3 subsystem and download confidential.txt encrypted."""
    import paramiko

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        hostname=LOOPBACK_HOST,
        port=PORTS["sftp"],
        username=username,
        password=password,
        look_for_keys=False,
        allow_agent=False,
        timeout=5,
    )
    transport = client.get_transport()
    cipher = transport.remote_cipher if transport else "unknown"
    sftp = client.open_sftp()
    files = sftp.listdir("/home/lab")
    with sftp.open("/home/lab/confidential.txt", "r") as f:
        data = f.read()
    sftp.close()
    client.close()
    return {
        "protocol": "sftp",
        "ok": len(data) > 0,
        "cipher": cipher,
        "files": files,
        "bytes_transferred": len(data),
        "steps": [
            "SSH-2.0 Handshake + Curve25519/DH Key Exchange",
            f"Encrypted password authentication ({cipher})",
            f"Encrypted SFTP v3 subsystem: LIST /home/lab + GET confidential.txt ({len(data)} bytes)",
        ],
    }


def run_udp_login(username: str, password: str) -> dict[str, Any]:
    """Send a connectionless UDP cleartext auth/syslog datagram for TCP vs UDP comparison."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(3.0)
    msg = (
        f"AUTH_REQ user={username} pass={password} "
        f"host=lab-workstation proto=UDP/{PORTS['udp_demo']} notice=NO_HANDSHAKE_CLEARTEXT"
    ).encode("utf-8")
    sock.sendto(msg, (LOOPBACK_HOST, PORTS["udp_demo"]))
    reply, _ = sock.recvfrom(4096)
    sock.close()
    return {
        "protocol": "udp_demo",
        "ok": b"AUTH_OK" in reply,
        "reply": reply.decode("utf-8", errors="replace"),
        "steps": [
            "Sent 1 UDP datagram (8-byte UDP header, NO 3-way handshake)",
            f"Received 1 UDP reply: {reply.decode('utf-8', errors='replace')[:80]}",
        ],
    }


CLIENT_RUNNERS = {
    "http": run_http_login,
    "https": run_https_login,
    "ftp": run_ftp_login,
    "telnet": run_telnet_login,
    "ssh": run_ssh_login,
    "sftp": run_sftp_login,
    "udp_demo": run_udp_login,
}
