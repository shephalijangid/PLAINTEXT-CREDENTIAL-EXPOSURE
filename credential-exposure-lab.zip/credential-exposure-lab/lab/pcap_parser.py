"""
Pure-Python standard libpcap (.pcap) binary reader and deep protocol dissector.
Dissects Ethernet/SLL -> IPv4 -> TCP/UDP -> HTTP, FTP, Telnet, TLS (HTTPS), SSH/SFTP, UDP,
computes Wireshark-style relative Seq/Ack numbers, reassembles TCP streams, and builds hex dumps.
"""

from __future__ import annotations

import base64
import socket
import struct
from pathlib import Path
from typing import Any

from .config import PORTS

# Telnet RFC 854 constants
TELNET_CMDS = {251: "WILL", 252: "WONT", 253: "DO", 254: "DONT", 250: "SB", 240: "SE"}
TELNET_OPTS = {1: "ECHO", 3: "SUPPRESS-GO-AHEAD", 24: "TERMINAL-TYPE", 31: "NAWS", 32: "TERMINAL-SPEED"}

# TLS record & handshake types
TLS_CONTENT_TYPES = {
    20: "ChangeCipherSpec",
    21: "Alert",
    22: "Handshake",
    23: "Application Data",
}
TLS_HANDSHAKE_TYPES = {
    1: "ClientHello",
    2: "ServerHello",
    4: "NewSessionTicket",
    8: "EncryptedExtensions",
    11: "Certificate",
    12: "ServerKeyExchange",
    14: "ServerHelloDone",
    15: "CertificateVerify",
    16: "ClientKeyExchange",
    20: "Finished",
}
TLS_VERSIONS = {
    0x0300: "SSL 3.0",
    0x0301: "TLS 1.0",
    0x0302: "TLS 1.1",
    0x0303: "TLS 1.2",
    0x0304: "TLS 1.3",
}

SSH_MSG_CODES = {
    1: "SSH_MSG_DISCONNECT",
    2: "SSH_MSG_IGNORE",
    20: "SSH_MSG_KEXINIT",
    21: "SSH_MSG_NEWKEYS",
    30: "SSH_MSG_KEX_ECDH_INIT",
    31: "SSH_MSG_KEX_ECDH_REPLY",
}


def format_hex_dump(data: bytes, max_bytes: int = 512) -> list[dict[str, str]]:
    """Format raw bytes into classic 16-byte Wireshark hex + ASCII rows."""
    rows = []
    sliced = data[:max_bytes]
    for offset in range(0, len(sliced), 16):
        chunk = sliced[offset : offset + 16]
        hex_left = " ".join(f"{b:02x}" for b in chunk[:8])
        hex_right = " ".join(f"{b:02x}" for b in chunk[8:])
        hex_str = f"{hex_left:<23}  {hex_right:<23}".rstrip()
        ascii_str = "".join(chr(b) if 32 <= b <= 126 else "." for b in chunk)
        rows.append(
            {
                "offset": f"{offset:04x}",
                "hex": hex_str,
                "ascii": ascii_str,
            }
        )
    return rows


def _parse_tls_client_hello(hs_body: bytes) -> dict[str, Any]:
    """Extract TLS version, offered cipher suite count, and SNI hostname from ClientHello."""
    info: dict[str, Any] = {}
    if len(hs_body) < 38:
        return info
    client_ver = struct.unpack("!H", hs_body[0:2])[0]
    info["client_version"] = TLS_VERSIONS.get(client_ver, f"0x{client_ver:04x}")
    idx = 2 + 32  # skip version + 32-byte random
    if idx >= len(hs_body):
        return info
    sess_len = hs_body[idx]
    idx += 1 + sess_len
    if idx + 2 > len(hs_body):
        return info
    cs_len = struct.unpack("!H", hs_body[idx : idx + 2])[0]
    info["cipher_suites_offered"] = cs_len // 2
    idx += 2 + cs_len
    if idx >= len(hs_body):
        return info
    comp_len = hs_body[idx]
    idx += 1 + comp_len
    if idx + 2 > len(hs_body):
        return info
    ext_total = struct.unpack("!H", hs_body[idx : idx + 2])[0]
    idx += 2
    end = min(len(hs_body), idx + ext_total)
    sni_hosts = []
    supported_versions = []
    while idx + 4 <= end:
        ext_type, ext_len = struct.unpack("!HH", hs_body[idx : idx + 4])
        ext_data = hs_body[idx + 4 : idx + 4 + ext_len]
        idx += 4 + ext_len
        if ext_type == 0x0000 and len(ext_data) >= 5:  # server_name (SNI)
            pos = 2  # skip list length
            while pos + 3 <= len(ext_data):
                name_type = ext_data[pos]
                name_len = struct.unpack("!H", ext_data[pos + 1 : pos + 3])[0]
                if name_type == 0 and pos + 3 + name_len <= len(ext_data):
                    sni_hosts.append(ext_data[pos + 3 : pos + 3 + name_len].decode("ascii", errors="replace"))
                pos += 3 + name_len
        elif ext_type == 0x002B and len(ext_data) >= 3:  # supported_versions
            vlen = ext_data[0]
            for j in range(1, min(len(ext_data), 1 + vlen), 2):
                if j + 2 <= len(ext_data):
                    v = struct.unpack("!H", ext_data[j : j + 2])[0]
                    supported_versions.append(TLS_VERSIONS.get(v, f"0x{v:04x}"))
    if sni_hosts:
        info["sni"] = sni_hosts[0]
    if supported_versions:
        info["supported_versions"] = supported_versions
    return info


def _parse_tls_server_hello(hs_body: bytes) -> dict[str, Any]:
    """Extract ServerHello selected cipher suite and TLS 1.3 supported_versions extension."""
    info: dict[str, Any] = {}
    if len(hs_body) < 38:
        return info
    ver = struct.unpack("!H", hs_body[0:2])[0]
    info["legacy_version"] = TLS_VERSIONS.get(ver, f"0x{ver:04x}")
    idx = 2 + 32
    if idx >= len(hs_body):
        return info
    sess_len = hs_body[idx]
    idx += 1 + sess_len
    if idx + 3 > len(hs_body):
        return info
    cipher_id = struct.unpack("!H", hs_body[idx : idx + 2])[0]
    known_ciphers = {
        0x1301: "TLS_AES_128_GCM_SHA256",
        0x1302: "TLS_AES_256_GCM_SHA384",
        0x1303: "TLS_CHACHA20_POLY1305_SHA256",
        0xC02F: "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256",
        0xC030: "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384",
    }
    info["selected_cipher"] = known_ciphers.get(cipher_id, f"0x{cipher_id:04x}")
    idx += 3  # cipher(2) + compression(1)
    if idx + 2 <= len(hs_body):
        ext_total = struct.unpack("!H", hs_body[idx : idx + 2])[0]
        idx += 2
        end = min(len(hs_body), idx + ext_total)
        while idx + 4 <= end:
            ext_type, ext_len = struct.unpack("!HH", hs_body[idx : idx + 4])
            ext_data = hs_body[idx + 4 : idx + 4 + ext_len]
            idx += 4 + ext_len
            if ext_type == 0x002B and len(ext_data) == 2:
                sv = struct.unpack("!H", ext_data)[0]
                info["negotiated_version"] = TLS_VERSIONS.get(sv, f"0x{sv:04x}")
    return info


def _dissect_tls(payload: bytes) -> tuple[str, dict[str, Any]]:
    records = []
    idx = 0
    sni = None
    negotiated_ver = None
    selected_cipher = None
    while idx + 5 <= len(payload):
        ctype = payload[idx]
        if ctype not in TLS_CONTENT_TYPES:
            break
        rec_ver = struct.unpack("!H", payload[idx + 1 : idx + 3])[0]
        rec_len = struct.unpack("!H", payload[idx + 3 : idx + 5])[0]
        rec_body = payload[idx + 5 : idx + 5 + rec_len]
        idx += 5 + rec_len

        rec_info: dict[str, Any] = {
            "content_type": TLS_CONTENT_TYPES[ctype],
            "record_version": TLS_VERSIONS.get(rec_ver, f"0x{rec_ver:04x}"),
            "length": rec_len,
        }
        if ctype == 22 and len(rec_body) >= 4:
            hs_type = rec_body[0]
            hs_name = TLS_HANDSHAKE_TYPES.get(hs_type, f"Encrypted Handshake / Type {hs_type}")
            rec_info["handshake_type"] = hs_name
            hs_len = int.from_bytes(rec_body[1:4], "big")
            hs_body = rec_body[4 : 4 + hs_len]
            if hs_type == 1:
                ch = _parse_tls_client_hello(hs_body)
                rec_info.update(ch)
                sni = ch.get("sni")
            elif hs_type == 2:
                sh = _parse_tls_server_hello(hs_body)
                rec_info.update(sh)
                negotiated_ver = sh.get("negotiated_version")
                selected_cipher = sh.get("selected_cipher")
        elif ctype == 23:
            rec_info["note"] = "Encrypted HTTP/1.1 traffic (credentials & payload opaque to attacker)"
        records.append(rec_info)

    if not records:
        return "TLS Continuation / Encrypted Segment", {"encrypted": True, "length": len(payload)}

    parts = []
    for r in records:
        if r.get("handshake_type"):
            extra = f" (SNI={r['sni']})" if r.get("sni") else ""
            if r.get("negotiated_version"):
                extra += f" [{r['negotiated_version']}, {r.get('selected_cipher', '')}]"
            parts.append(f"{r['handshake_type']}{extra}")
        else:
            parts.append(f"{r['content_type']} ({r['length']}B)")
    summary = "TLS: " + ", ".join(parts)
    details = {"records": records}
    if sni:
        details["sni"] = sni
    if negotiated_ver:
        details["negotiated_version"] = negotiated_ver
    if selected_cipher:
        details["selected_cipher"] = selected_cipher
    return summary, details


def _parse_ssh_kexinit(body: bytes) -> dict[str, Any]:
    """Parse plaintext SSH_MSG_KEXINIT name-lists (KEX, host key, ciphers, MACs)."""
    if len(body) < 17:
        return {}
    idx = 17  # 1 byte msg_code + 16 byte cookie
    names = ["kex_algorithms", "server_host_key_algorithms", "encryption_c2s", "encryption_s2c", "mac_c2s", "mac_s2c"]
    out: dict[str, Any] = {}
    for field in names:
        if idx + 4 > len(body):
            break
        nlen = struct.unpack("!I", body[idx : idx + 4])[0]
        idx += 4
        if idx + nlen > len(body):
            break
        algos = body[idx : idx + nlen].decode("ascii", errors="replace").split(",")
        out[field] = algos[:5]
        idx += nlen
    return out


def _dissect_ssh(payload: bytes, state: dict[str, Any], direction: str) -> tuple[str, dict[str, Any]]:
    # Plaintext SSH version banner
    if payload.startswith(b"SSH-2.0-") or payload.startswith(b"SSH-1."):
        banner = payload.decode("ascii", errors="replace").strip()
        return f"SSH Protocol Banner: {banner}", {"banner": banner, "plaintext_metadata": True}

    # Once NEWKEYS has been sent in this direction, everything is encrypted binary ciphertext
    if state.get(f"encrypted_{direction}"):
        return (
            f"Encrypted SSH-2.0 Packet ({len(payload)} bytes ciphertext — credentials/commands hidden)",
            {"encrypted": True, "ciphertext_length": len(payload)},
        )

    # Pre-encryption SSH Binary Packet Protocol
    if len(payload) >= 6:
        pkt_len = struct.unpack("!I", payload[0:4])[0]
        pad_len = payload[4]
        msg_code = payload[5]
        if 0 < pkt_len <= 65536 and msg_code in SSH_MSG_CODES:
            msg_name = SSH_MSG_CODES[msg_code]
            details: dict[str, Any] = {
                "packet_length": pkt_len,
                "padding_length": pad_len,
                "message_code": msg_code,
                "message_name": msg_name,
            }
            if msg_code == 20:
                details.update(_parse_ssh_kexinit(payload[5 : 4 + pkt_len - pad_len]))
                details["plaintext_metadata"] = True
            if msg_code == 21:
                state[f"encrypted_{direction}"] = True
                details["note"] = "Encryption activated! All subsequent packets in this direction are ciphertext."
            # Check if NEWKEYS is bundled right after KEX_ECDH_REPLY in the same TCP segment
            next_off = 4 + pkt_len
            if next_off + 6 <= len(payload):
                next_len = struct.unpack("!I", payload[next_off : next_off + 4])[0]
                next_code = payload[next_off + 5]
                if 0 < next_len <= 65536 and next_code == 21:
                    state[f"encrypted_{direction}"] = True
                    msg_name += " + SSH_MSG_NEWKEYS (Encryption Activated)"
                    details["newkeys_bundled"] = True
            return f"SSH: {msg_name}", details

    # Fallback: post-handshake encrypted segment
    state[f"encrypted_{direction}"] = True
    return (
        f"Encrypted SSH-2.0 Packet ({len(payload)} bytes ciphertext)",
        {"encrypted": True, "ciphertext_length": len(payload)},
    )


def _dissect_http(payload: bytes) -> tuple[str, dict[str, Any]]:
    text = payload.decode("utf-8", errors="replace")
    # Handle standalone HTTP body TCP segment (when client/server splits headers and body)
    is_http_head = text.startswith(("GET ", "POST ", "PUT ", "DELETE ", "HEAD ", "OPTIONS ", "HTTP/"))
    if not is_http_head:
        stripped = text.strip()
        if "username=" in stripped or "password=" in stripped:
            return (
                f"HTTP Form POST Body: {stripped[:72]} [EXPOSED: Plaintext Form Credentials]",
                {"segment_type": "HTTP Request Body", "body": stripped},
            )
        if stripped.startswith("{") and stripped.endswith("}"):
            return (
                f"HTTP JSON Body: {stripped[:72]}",
                {"segment_type": "HTTP Response Body", "body": stripped},
            )
        return f"HTTP Continuation: {stripped[:72]}", {"segment_type": "HTTP Continuation", "body": stripped}

    parts = text.split("\r\n\r\n", 1)
    head = parts[0]
    body = parts[1] if len(parts) > 1 else ""
    lines = head.split("\r\n")
    first_line = lines[0] if lines else text[:80]
    headers: dict[str, str] = {}
    for ln in lines[1:]:
        if ":" in ln:
            k, v = ln.split(":", 1)
            headers[k.strip()] = v.strip()

    details: dict[str, Any] = {"first_line": first_line, "headers": headers}
    if body:
        details["body"] = body
    if "Authorization" in headers and headers["Authorization"].startswith("Basic "):
        b64_val = headers["Authorization"][6:].strip()
        try:
            details["decoded_basic_auth"] = base64.b64decode(b64_val).decode("utf-8", errors="replace")
        except Exception:
            pass
    summary = f"HTTP: {first_line}"
    if "decoded_basic_auth" in details:
        summary += " [EXPOSED: Basic Auth Header]"
    elif "password=" in body:
        summary += " [EXPOSED: Plaintext Form Credentials]"
    elif "Set-Cookie" in headers:
        summary += " [EXPOSED: Plaintext Session Cookie]"
    return summary, details


def _dissect_ftp(payload: bytes, is_data: bool) -> tuple[str, dict[str, Any]]:
    text = payload.decode("utf-8", errors="replace").strip()
    if is_data:
        preview = text.splitlines()[0] if text else f"{len(payload)} bytes"
        return f"FTP-DATA (Cleartext File): {preview[:70]}", {"channel": "PASV data", "plaintext_file": text}
    first = text.splitlines()[0] if text else ""
    details: dict[str, Any] = {"channel": "control", "line": text}
    upper = first.upper()
    if upper.startswith("USER "):
        details["credential_field"] = "username"
        return f"FTP Request: {first}  [EXPOSED USERNAME]", details
    if upper.startswith("PASS "):
        details["credential_field"] = "password"
        return f"FTP Request: {first}  [EXPOSED PASSWORD]", details
    if first[:3].isdigit():
        return f"FTP Response: {first}", details
    return f"FTP Request: {first}", details


def _dissect_telnet(payload: bytes) -> tuple[str, dict[str, Any]]:
    iac_cmds = []
    printable = []
    i = 0
    while i < len(payload):
        if payload[i] == 255 and i + 2 < len(payload):
            cmd = TELNET_CMDS.get(payload[i + 1], str(payload[i + 1]))
            opt = TELNET_OPTS.get(payload[i + 2], str(payload[i + 2]))
            iac_cmds.append(f"IAC {cmd} {opt}")
            i += 3
        else:
            b = payload[i]
            if b == 13:
                printable.append("\\r")
            elif b == 10:
                printable.append("\\n")
            elif 32 <= b <= 126:
                printable.append(chr(b))
            i += 1

    text = "".join(printable)
    details: dict[str, Any] = {}
    if iac_cmds:
        details["iac_commands"] = iac_cmds
    if text:
        details["terminal_data"] = text

    if iac_cmds and not text:
        return "Telnet Options: " + ", ".join(iac_cmds), details
    if len(payload) == 1 and 32 <= payload[0] <= 126:
        return f"Telnet Keystroke (1 byte): '{chr(payload[0])}'", details
    clean = text.replace("\\r\\n", " ").strip()
    return f"Telnet Data: {clean[:72]}", details


def parse_pcap(pcap_path: Path, protocol_hint: str) -> dict[str, Any]:
    """
    Parse a standard libpcap (.pcap) file and return structured Wireshark-like data:
    - packets: list of dissected frames (L2/L3/L4/L7 + hex dump)
    - streams: reassembled directional application streams (Follow TCP/UDP Stream)
    - summary: packet count, byte totals, TCP vs UDP metrics
    """
    if not pcap_path.exists():
        return {"exists": False, "packets": [], "streams": [], "summary": {}}

    raw = pcap_path.read_bytes()
    if len(raw) < 24:
        return {"exists": True, "packets": [], "streams": [], "summary": {"error": "Empty PCAP"}}

    magic = raw[0:4]
    if magic == b"\xd4\xc3\xb2\xa1":
        endian, ts_div = "<", 1_000_000.0
    elif magic == b"\xa1\xb2\xc3\xd4":
        endian, ts_div = ">", 1_000_000.0
    elif magic == b"\x4d\x3c\xb2\xa1":
        endian, ts_div = "<", 1_000_000_000.0
    elif magic == b"\xa1\xb2\x3c\x4d":
        endian, ts_div = ">", 1_000_000_000.0
    else:
        raise ValueError(f"Unsupported pcap magic bytes: {magic.hex()}")

    _m, ver_maj, ver_min, _tz, _sf, snaplen, linktype = struct.unpack(endian + "IHHiIII", raw[0:24])

    server_ports = {
        "http": {PORTS["http"]},
        "https": {PORTS["https"]},
        "ftp": {PORTS["ftp"], PORTS["ftp_data"]},
        "telnet": {PORTS["telnet"]},
        "ssh": {PORTS["ssh"]},
        "sftp": {PORTS["sftp"]},
        "udp_demo": {PORTS["udp_demo"]},
    }.get(protocol_hint, set())

    packets: list[dict[str, Any]] = []
    streams: dict[str, list[dict[str, Any]]] = {}
    base_ts: float | None = None
    # Track initial sequence numbers per flow for Wireshark-style relative seq/ack
    isn_map: dict[tuple[str, int, str, int], int] = {}
    ssh_state: dict[str, Any] = {}

    offset = 24
    frame_no = 0
    total_bytes = 0
    tcp_handshakes = 0
    udp_datagrams = 0

    while offset + 16 <= len(raw):
        ts_sec, ts_sub, incl_len, orig_len = struct.unpack(endian + "IIII", raw[offset : offset + 16])
        offset += 16
        frame_bytes = raw[offset : offset + incl_len]
        offset += incl_len
        if len(frame_bytes) < incl_len:
            break

        frame_no += 1
        total_bytes += orig_len
        ts = ts_sec + ts_sub / ts_div
        if base_ts is None:
            base_ts = ts
        rel_time = round(ts - base_ts, 6)

        # Link layer decoding
        l2: dict[str, Any] = {"linktype": linktype}
        if linktype == 1 and len(frame_bytes) >= 14:  # Ethernet EN10MB
            dst_mac = ":".join(f"{b:02x}" for b in frame_bytes[0:6])
            src_mac = ":".join(f"{b:02x}" for b in frame_bytes[6:12])
            ethertype = struct.unpack("!H", frame_bytes[12:14])[0]
            l2.update({"type": "Ethernet II", "src_mac": src_mac, "dst_mac": dst_mac, "ethertype": f"0x{ethertype:04x}"})
            ip_off = 14
        elif linktype == 113 and len(frame_bytes) >= 16:  # Linux SLL
            ethertype = struct.unpack("!H", frame_bytes[14:16])[0]
            l2.update({"type": "Linux Cooked SLL", "ethertype": f"0x{ethertype:04x}"})
            ip_off = 16
        elif linktype == 0 and len(frame_bytes) >= 4:  # BSD Loopback
            ethertype = 0x0800
            l2.update({"type": "Loopback NULL"})
            ip_off = 4
        else:
            continue

        if ethertype != 0x0800 or len(frame_bytes) < ip_off + 20:
            continue

        # IPv4 Header
        ver_ihl = frame_bytes[ip_off]
        ihl = (ver_ihl & 0x0F) * 4
        ip_tot_len = struct.unpack("!H", frame_bytes[ip_off + 2 : ip_off + 4])[0]
        ip_id = struct.unpack("!H", frame_bytes[ip_off + 4 : ip_off + 6])[0]
        ttl = frame_bytes[ip_off + 8]
        ip_proto = frame_bytes[ip_off + 9]
        src_ip = socket.inet_ntoa(frame_bytes[ip_off + 12 : ip_off + 16])
        dst_ip = socket.inet_ntoa(frame_bytes[ip_off + 16 : ip_off + 20])

        l3 = {
            "version": 4,
            "header_length": ihl,
            "total_length": ip_tot_len,
            "identification": f"0x{ip_id:04x}",
            "ttl": ttl,
            "protocol_num": ip_proto,
            "protocol_name": "TCP" if ip_proto == 6 else ("UDP" if ip_proto == 17 else str(ip_proto)),
            "src_ip": src_ip,
            "dst_ip": dst_ip,
        }

        l4_off = ip_off + ihl
        ip_end = min(len(frame_bytes), ip_off + ip_tot_len)
        l4: dict[str, Any] = {}
        app_payload = b""
        app_proto_label = l3["protocol_name"]
        info_text = ""
        app_details: dict[str, Any] = {}
        direction = "unknown"
        src_port = 0
        dst_port = 0

        if ip_proto == 6 and len(frame_bytes) >= l4_off + 20:  # TCP
            src_port, dst_port, seq, ack, off_flags, window, csum, urgp = struct.unpack(
                "!HHIIHHHH", frame_bytes[l4_off : l4_off + 20]
            )
            tcp_hdr_len = ((off_flags >> 12) & 0xF) * 4
            flags_bits = off_flags & 0x3F
            flag_names = []
            for bit, name in [(0x02, "SYN"), (0x10, "ACK"), (0x08, "PSH"), (0x01, "FIN"), (0x04, "RST"), (0x20, "URG")]:
                if flags_bits & bit:
                    flag_names.append(name)

            flow_fwd = (src_ip, src_port, dst_ip, dst_port)
            flow_rev = (dst_ip, dst_port, src_ip, src_port)
            if flow_fwd not in isn_map:
                isn_map[flow_fwd] = seq
            rel_seq = (seq - isn_map[flow_fwd]) & 0xFFFFFFFF
            rel_ack = ((ack - isn_map[flow_rev]) & 0xFFFFFFFF) if ("ACK" in flag_names and flow_rev in isn_map) else 0

            app_payload = frame_bytes[l4_off + tcp_hdr_len : ip_end]
            direction = "client->server" if dst_port in server_ports else "server->client"

            if "SYN" in flag_names and "ACK" not in flag_names:
                tcp_handshakes += 1

            l4 = {
                "transport": "TCP",
                "src_port": src_port,
                "dst_port": dst_port,
                "header_length": tcp_hdr_len,
                "seq": seq,
                "ack": ack,
                "rel_seq": rel_seq,
                "rel_ack": rel_ack,
                "flags": flag_names,
                "window": window,
                "checksum": f"0x{csum:04x}",
                "payload_length": len(app_payload),
            }

            flags_str = ", ".join(flag_names)
            info_text = f"{src_port} -> {dst_port} [{flags_str}] Seq={rel_seq} Ack={rel_ack} Win={window} Len={len(app_payload)}"

            if app_payload:
                stream_key = f"tcp:{min(src_port, dst_port)}-{max(src_port, dst_port)}"
                if protocol_hint == "ftp" and (src_port == PORTS["ftp_data"] or dst_port == PORTS["ftp_data"]):
                    stream_key = "ftp-data-channel"
                streams.setdefault(stream_key, []).append(
                    {
                        "frame": frame_no,
                        "time": rel_time,
                        "direction": direction,
                        "src_port": src_port,
                        "dst_port": dst_port,
                        "length": len(app_payload),
                        "raw_bytes": app_payload,
                    }
                )

                if protocol_hint == "http":
                    app_proto_label = "HTTP"
                    info_text, app_details = _dissect_http(app_payload)
                elif protocol_hint == "https":
                    app_proto_label = "TLS"
                    info_text, app_details = _dissect_tls(app_payload)
                elif protocol_hint == "ftp":
                    is_data = src_port == PORTS["ftp_data"] or dst_port == PORTS["ftp_data"]
                    app_proto_label = "FTP-DATA" if is_data else "FTP"
                    info_text, app_details = _dissect_ftp(app_payload, is_data)
                elif protocol_hint == "telnet":
                    app_proto_label = "TELNET"
                    info_text, app_details = _dissect_telnet(app_payload)
                elif protocol_hint in ("ssh", "sftp"):
                    app_proto_label = "SFTP/SSH" if protocol_hint == "sftp" else "SSH"
                    info_text, app_details = _dissect_ssh(app_payload, ssh_state, direction)

        elif ip_proto == 17 and len(frame_bytes) >= l4_off + 8:  # UDP
            src_port, dst_port, udp_len, csum = struct.unpack("!HHHH", frame_bytes[l4_off : l4_off + 8])
            app_payload = frame_bytes[l4_off + 8 : min(ip_end, l4_off + udp_len)]
            direction = "client->server" if dst_port in server_ports else "server->client"
            udp_datagrams += 1
            app_proto_label = "UDP"
            l4 = {
                "transport": "UDP",
                "src_port": src_port,
                "dst_port": dst_port,
                "header_length": 8,
                "udp_length": udp_len,
                "checksum": f"0x{csum:04x}",
                "payload_length": len(app_payload),
            }
            text = app_payload.decode("utf-8", errors="replace").strip()
            info_text = f"UDP {src_port} -> {dst_port} Len={len(app_payload)}: {text[:80]}"
            app_details = {"datagram_text": text, "header_note": "Connectionless 8-byte UDP header (no handshake, no Seq/Ack)"}
            streams.setdefault("udp-datagrams", []).append(
                {
                    "frame": frame_no,
                    "time": rel_time,
                    "direction": direction,
                    "src_port": src_port,
                    "dst_port": dst_port,
                    "length": len(app_payload),
                    "raw_bytes": app_payload,
                }
            )
        else:
            continue

        # Flag whether packet carries exposed plaintext credential keywords for UI highlighting
        payload_ascii = "".join(chr(b) if 32 <= b <= 126 else "." for b in app_payload)
        packets.append(
            {
                "no": frame_no,
                "time": rel_time,
                "src": f"{src_ip}:{src_port}",
                "dst": f"{dst_ip}:{dst_port}",
                "src_ip": src_ip,
                "dst_ip": dst_ip,
                "src_port": src_port,
                "dst_port": dst_port,
                "protocol": app_proto_label,
                "transport": l3["protocol_name"],
                "length": orig_len,
                "payload_length": len(app_payload),
                "direction": direction,
                "info": info_text,
                "layers": {
                    "frame": {"number": frame_no, "captured_length": incl_len, "wire_length": orig_len, "time_relative": rel_time},
                    "link": l2,
                    "ip": l3,
                    "transport": l4,
                    "application": app_details,
                },
                "payload_ascii": payload_ascii[:512],
                "hex_dump": format_hex_dump(frame_bytes, max_bytes=384),
            }
        )

    # Convert streams to JSON-serializable structure
    serializable_streams = []
    for key, chunks in streams.items():
        combined_items = []
        raw_all = bytearray()
        for ch in chunks:
            raw_b: bytes = ch["raw_bytes"]
            raw_all.extend(raw_b)
            # Strip Telnet IAC bytes for readable stream rendering while noting them
            printable = "".join(
                chr(b) if (32 <= b <= 126 or b in (10, 13, 9)) else "."
                for b in raw_b
            )
            combined_items.append(
                {
                    "frame": ch["frame"],
                    "time": ch["time"],
                    "direction": ch["direction"],
                    "length": ch["length"],
                    "text": printable[:2000],
                    "hex_preview": raw_b[:48].hex(" "),
                }
            )
        serializable_streams.append(
            {
                "stream_id": key,
                "chunk_count": len(combined_items),
                "total_payload_bytes": len(raw_all),
                "chunks": combined_items,
            }
        )

    return {
        "exists": True,
        "pcap_file": pcap_path.name,
        "pcap_size_bytes": len(raw),
        "pcap_version": f"{ver_maj}.{ver_min}",
        "linktype": linktype,
        "packets": packets,
        "streams": serializable_streams,
        "summary": {
            "packet_count": len(packets),
            "total_wire_bytes": total_bytes,
            "duration_sec": packets[-1]["time"] if packets else 0.0,
            "tcp_handshakes": tcp_handshakes,
            "udp_datagrams": udp_datagrams,
            "payload_packets": sum(1 for p in packets if p["payload_length"] > 0),
        },
    }
