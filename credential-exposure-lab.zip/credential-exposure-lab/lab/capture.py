"""
Real packet capture engine on loopback (`lo`) producing standard libpcap (.pcap) files
readable by Wireshark, tshark, and tcpdump.
Uses `tcpdump --immediate-mode` when available, with a pure-Python AF_PACKET fallback.
"""

from __future__ import annotations

import getpass
import os
import shutil
import socket
import struct
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Callable, Optional

from .config import CAPTURES_DIR, PROTOCOLS


def detect_capture_capability() -> dict[str, Any]:
    """Detect whether live packet capture (tcpdump / sudo / raw sockets) is available."""
    tcpdump_bin = shutil.which("tcpdump")
    is_root = os.geteuid() == 0
    sudo_ok = False
    if not is_root and shutil.which("sudo"):
        res = subprocess.run(["sudo", "-n", "true"], capture_output=True)
        sudo_ok = res.returncode == 0

    can_tcpdump = bool(tcpdump_bin and (is_root or sudo_ok))
    can_raw = is_root
    return {
        "tcpdump_path": tcpdump_bin,
        "is_root": is_root,
        "sudo_nopasswd": sudo_ok,
        "live_capture_available": can_tcpdump or can_raw,
        "method": "tcpdump" if can_tcpdump else ("af_packet" if can_raw else "replay_only"),
    }


class _PurePythonLoCapture:
    """Fallback pure-Python AF_PACKET sniffer writing standard libpcap EN10MB .pcap files."""

    PCAP_GLOBAL_HEADER = struct.pack("<IHHiIII", 0xA1B2C3D4, 2, 4, 0, 0, 65535, 1)

    def __init__(self, pcap_path: Path, ports: set[int], transport: str):
        self.pcap_path = pcap_path
        self.ports = ports
        self.transport = transport.upper()
        self._stop = threading.Event()
        self._packets: list[tuple[int, int, bytes]] = []
        self._thread: Optional[threading.Thread] = None

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        time.sleep(0.1)

    def _matches(self, frame: bytes) -> bool:
        if len(frame) < 34:
            return False
        ethertype = struct.unpack("!H", frame[12:14])[0]
        if ethertype != 0x0800:
            return False
        ihl = (frame[14] & 0x0F) * 4
        proto = frame[23]
        if self.transport == "TCP" and proto != 6:
            return False
        if self.transport == "UDP" and proto != 17:
            return False
        off = 14 + ihl
        if len(frame) < off + 4:
            return False
        sport, dport = struct.unpack("!HH", frame[off : off + 4])
        return sport in self.ports or dport in self.ports

    def _run(self):
        sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(3))
        sock.bind(("lo", 0))
        sock.settimeout(0.2)
        try:
            while not self._stop.is_set():
                try:
                    raw, addr = sock.recvfrom(65535)
                except socket.timeout:
                    continue
                # On Linux loopback, AF_PACKET sees both OUTGOING and INCOMING; keep OUTGOING only to avoid duplicates
                if addr[2] == socket.PACKET_OUTGOING:
                    continue
                if self._matches(raw):
                    now = time.time()
                    sec = int(now)
                    usec = int((now - sec) * 1_000_000)
                    self._packets.append((sec, usec, raw))
        finally:
            sock.close()

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2.0)
        self.pcap_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.pcap_path, "wb") as f:
            f.write(self.PCAP_GLOBAL_HEADER)
            for sec, usec, raw in self._packets:
                f.write(struct.pack("<IIII", sec, usec, len(raw), len(raw)))
                f.write(raw)


def capture_protocol_session(
    protocol_id: str,
    action_fn: Callable[[], dict[str, Any]],
    pcap_path: Optional[Path] = None,
) -> dict[str, Any]:
    """
    Start a live loopback packet capture for `protocol_id`, execute `action_fn()`,
    flush the .pcap file, and return capture metadata + client execution result.
    """
    if protocol_id not in PROTOCOLS:
        raise ValueError(f"Unknown protocol: {protocol_id}")

    meta = PROTOCOLS[protocol_id]
    CAPTURES_DIR.mkdir(parents=True, exist_ok=True)
    target_pcap = pcap_path or (CAPTURES_DIR / meta["pcap_file"])
    cap_info = detect_capture_capability()

    if not cap_info["live_capture_available"]:
        raise PermissionError(
            "Live packet capture requires tcpdump with sudo/root privileges (or root AF_PACKET). "
            "Pre-captured lab .pcap files are still available for inspection."
        )

    if cap_info["method"] == "tcpdump":
        user = getpass.getuser()
        cmd = []
        if not cap_info["is_root"]:
            cmd.extend(["sudo", "-n"])
        cmd.extend(
            [
                cap_info["tcpdump_path"],
                "-i",
                "lo",
                "--immediate-mode",
                "-U",
                "-n",
                "-s",
                "0",
            ]
        )
        if not cap_info["is_root"]:
            cmd.extend(["-Z", user])
        cmd.extend(["-w", str(target_pcap), meta["bpf_filter"]])

        # Remove old capture file cleanly so tcpdump can recreate with user ownership
        if target_pcap.exists():
            try:
                target_pcap.unlink()
            except PermissionError:
                subprocess.run(["sudo", "-n", "rm", "-f", str(target_pcap)], check=False)

        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        # Wait for tcpdump to report "listening on lo"
        ready_line = ""
        deadline = time.time() + 5.0
        while time.time() < deadline:
            line = proc.stderr.readline()
            if not line:
                if proc.poll() is not None:
                    break
                time.sleep(0.02)
                continue
            ready_line = line.strip()
            if "listening on" in ready_line.lower():
                break

        time.sleep(0.12)
        started_at = time.time()
        client_error = None
        client_result: dict[str, Any] = {}
        try:
            client_result = action_fn()
        except Exception as exc:
            client_error = str(exc)

        # Allow final FIN/ACK packets to arrive in ring buffer
        time.sleep(0.30)

        # Cleanly stop tcpdump with SIGINT so pcap trailer & stats flush properly
        if cap_info["is_root"]:
            proc.send_signal(2)
        else:
            subprocess.run(["sudo", "-n", "pkill", "-INT", "-P", str(proc.pid)], check=False)
            # Also signal proc itself in case sudo wasn't a wrapper child
            subprocess.run(["sudo", "-n", "kill", "-INT", str(proc.pid)], check=False)

        try:
            _, stderr_tail = proc.communicate(timeout=4)
        except subprocess.TimeoutExpired:
            subprocess.run(["sudo", "-n", "pkill", "-KILL", "-P", str(proc.pid)], check=False)
            proc.kill()
            _, stderr_tail = proc.communicate()

        elapsed_ms = int((time.time() - started_at) * 1000)

        if client_error:
            raise RuntimeError(f"Client session failed for {protocol_id}: {client_error}")

        return {
            "protocol": protocol_id,
            "pcap_path": str(target_pcap),
            "pcap_size_bytes": target_pcap.stat().st_size if target_pcap.exists() else 0,
            "capture_method": "tcpdump",
            "bpf_filter": meta["bpf_filter"],
            "tcpdump_ready": ready_line,
            "tcpdump_stats": stderr_tail.strip(),
            "duration_ms": elapsed_ms,
            "client_result": client_result,
        }

    # Pure-Python AF_PACKET fallback
    ports = {meta["lab_port"]}
    if "data_port" in meta:
        ports.add(meta["data_port"])
    sniffer = _PurePythonLoCapture(target_pcap, ports, meta["transport"])
    sniffer.start()
    started_at = time.time()
    try:
        client_result = action_fn()
    finally:
        time.sleep(0.25)
        sniffer.stop()
    elapsed_ms = int((time.time() - started_at) * 1000)
    return {
        "protocol": protocol_id,
        "pcap_path": str(target_pcap),
        "pcap_size_bytes": target_pcap.stat().st_size if target_pcap.exists() else 0,
        "capture_method": "af_packet",
        "bpf_filter": meta["bpf_filter"],
        "tcpdump_ready": "AF_PACKET listening on lo",
        "tcpdump_stats": f"{len(sniffer._packets)} packets captured",
        "duration_ms": elapsed_ms,
        "client_result": client_result,
    }


def get_tcpdump_text(pcap_path: Path, hex_ascii: bool = False, max_chars: int = 12000) -> str:
    """Return authentic `tcpdump -nn -r` (or `-nn -X -r`) CLI output for a .pcap file."""
    tcpdump_bin = shutil.which("tcpdump")
    if not tcpdump_bin or not pcap_path.exists():
        return ""
    args = [tcpdump_bin, "-nn", "-r", str(pcap_path)]
    if hex_ascii:
        args.insert(2, "-X")
    res = subprocess.run(args, capture_output=True, text=True, timeout=10)
    out = res.stdout or ""
    if len(out) > max_chars:
        out = out[:max_chars] + f"\n... [truncated {len(out) - max_chars} chars — download full .pcap for Wireshark]"
    return out
