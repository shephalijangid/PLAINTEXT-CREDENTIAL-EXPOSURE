"""
Real local loopback lab servers for all 6 protocols + UDP comparison:
  - HTTP  (127.0.0.1:18080)  - Form POST + Basic Auth
  - HTTPS (127.0.0.1:18443)  - TLS 1.3/1.2 Form POST + Basic Auth
  - FTP   (127.0.0.1:12121 / data 12122) - RFC 959 Control + PASV Data
  - Telnet(127.0.0.1:12323)  - RFC 854 IAC Negotiation + Character-by-Character Login
  - SSH   (127.0.0.1:12222)  - RFC 4251-4254 SSH-2.0 Remote Shell (paramiko)
  - SFTP  (127.0.0.1:12223)  - RFC 4251-4254 SSH-2.0 + SFTP v3 File Transfer (paramiko)
  - UDP   (127.0.0.1:15140)  - Connectionless UDP Auth/Syslog Datagram
"""

from __future__ import annotations

import base64
import http.server
import io
import json
import os
import socket
import ssl
import stat
import threading
import time
import urllib.parse
from typing import Optional

from .certs import ensure_ssh_host_key, ensure_tls_cert
from .config import LOOPBACK_HOST, PORTS

CONFIDENTIAL_FILE_CONTENT = (
    b"=== EXP 4 CONFIDENTIAL LAB DOCUMENT ===\n"
    b"Project: Plaintext Credential Exposure Study\n"
    b"Secret-Token: LAB-FILE-TOKEN-9942-XYZ\n"
    b"Notice: If you can read this in Wireshark/tcpdump, the transfer was UNENCRYPTED!\n"
)

SHELL_SECRET_OUTPUT = "LAB_SECRET_FLAG=EXP4_NETWORK_SECURITY_2026\n"


class _ReusableHTTPServer(http.server.ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def _make_http_handler(protocol_label: str):
    class LabAuthHTTPHandler(http.server.BaseHTTPRequestHandler):
        server_version = f"LabPortal-{protocol_label}/1.0"
        sys_version = ""

        def log_message(self, fmt, *args):
            return  # Keep stdout clean

        def do_GET(self):
            if self.path == "/api/profile":
                auth = self.headers.get("Authorization", "")
                user = "anonymous"
                if auth.startswith("Basic "):
                    try:
                        decoded = base64.b64decode(auth[6:].strip()).decode("utf-8", errors="replace")
                        user = decoded.split(":", 1)[0]
                    except Exception:
                        pass
                payload = json.dumps(
                    {
                        "status": "ok",
                        "transport": protocol_label,
                        "authenticated_user": user,
                        "secret_note": f"Authenticated profile data delivered over {protocol_label}",
                    }
                ).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
                return

            body = f"<html><body><h1>Exp 4 {protocol_label} Lab Portal</h1></body></html>".encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            length = int(self.headers.get("Content-Length", "0"))
            raw_body = self.rfile.read(length).decode("utf-8", errors="replace")
            params = urllib.parse.parse_qs(raw_body)
            username = params.get("username", ["unknown"])[0]

            session_token = (
                "sess_http_plain_8f7a6c5d" if protocol_label == "HTTP" else "sess_https_tls_3e4f9a1b"
            )
            payload = json.dumps(
                {
                    "status": "authenticated",
                    "protocol": protocol_label,
                    "username": username,
                    "session_token": session_token,
                    "message": f"Login accepted over {protocol_label}",
                }
            ).encode("utf-8")

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            cookie_flags = "; HttpOnly" + ("; Secure" if protocol_label == "HTTPS" else "")
            self.send_header("Set-Cookie", f"lab_session={session_token}; Path=/{cookie_flags}")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

    return LabAuthHTTPHandler


class LabFTPServer:
    """Minimal authentic RFC 959 FTP server supporting USER/PASS/SYST/PWD/PASV/LIST/RETR/QUIT."""

    def __init__(self, host: str, port: int, data_port: int):
        self.host = host
        self.port = port
        self.data_port = data_port
        self._stop = threading.Event()
        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None

    def start(self):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((self.host, self.port))
        self._sock.listen(8)
        self._sock.settimeout(0.5)
        self._thread = threading.Thread(target=self._serve, daemon=True, name="lab-ftp")
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._sock:
            try:
                self._sock.close()
            except OSError:
                pass

    def _serve(self):
        while not self._stop.is_set():
            try:
                conn, _ = self._sock.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self._handle_client, args=(conn,), daemon=True).start()

    def _handle_client(self, conn: socket.socket):
        data_listener: Optional[socket.socket] = None
        username = ""
        try:
            conn.settimeout(5.0)
            conn.sendall(b"220 Lab-FTP-Server (RFC 959 Plaintext) Ready\r\n")
            buf = b""
            while not self._stop.is_set():
                chunk = conn.recv(4096)
                if not chunk:
                    break
                buf += chunk
                while b"\n" in buf:
                    line_bytes, buf = buf.split(b"\n", 1)
                    line = line_bytes.decode("utf-8", errors="replace").strip()
                    if not line:
                        continue
                    parts = line.split(" ", 1)
                    cmd = parts[0].upper()
                    arg = parts[1] if len(parts) > 1 else ""

                    if cmd == "USER":
                        username = arg
                        conn.sendall(f"331 Password required for {username}\r\n".encode())
                    elif cmd == "PASS":
                        conn.sendall(f"230 User {username} logged in successfully.\r\n".encode())
                    elif cmd == "SYST":
                        conn.sendall(b"215 UNIX Type: L8\r\n")
                    elif cmd == "FEAT":
                        conn.sendall(b"211-Features:\r\n PASV\r\n UTF8\r\n211 End\r\n")
                    elif cmd == "PWD" or cmd == "XPWD":
                        conn.sendall(b'257 "/home/lab" is current directory.\r\n')
                    elif cmd == "TYPE":
                        conn.sendall(f"200 Type set to {arg or 'I'}.\r\n".encode())
                    elif cmd == "PASV":
                        if data_listener:
                            try:
                                data_listener.close()
                            except OSError:
                                pass
                        data_listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        data_listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                        data_listener.bind((self.host, self.data_port))
                        data_listener.listen(1)
                        data_listener.settimeout(5.0)
                        p1, p2 = divmod(self.data_port, 256)
                        conn.sendall(f"227 Entering Passive Mode (127,0,0,1,{p1},{p2}).\r\n".encode())
                    elif cmd == "RETR":
                        if not data_listener:
                            conn.sendall(b"425 Use PASV first.\r\n")
                            continue
                        conn.sendall(b"150 Opening BINARY mode data connection for confidential.txt.\r\n")
                        try:
                            data_conn, _ = data_listener.accept()
                            data_conn.sendall(CONFIDENTIAL_FILE_CONTENT)
                            data_conn.close()
                        finally:
                            data_listener.close()
                            data_listener = None
                        conn.sendall(b"226 Transfer complete.\r\n")
                    elif cmd == "LIST":
                        if not data_listener:
                            conn.sendall(b"425 Use PASV first.\r\n")
                            continue
                        conn.sendall(b"150 Opening ASCII mode data connection for file list.\r\n")
                        try:
                            data_conn, _ = data_listener.accept()
                            listing = f"-rw-r--r-- 1 lab lab {len(CONFIDENTIAL_FILE_CONTENT)} Nov 16 12:00 confidential.txt\r\n".encode()
                            data_conn.sendall(listing)
                            data_conn.close()
                        finally:
                            data_listener.close()
                            data_listener = None
                        conn.sendall(b"226 Transfer complete.\r\n")
                    elif cmd == "QUIT":
                        conn.sendall(b"221 Goodbye.\r\n")
                        return
                    else:
                        conn.sendall(f"502 Command {cmd} not implemented.\r\n".encode())
        except Exception:
            pass
        finally:
            if data_listener:
                try:
                    data_listener.close()
                except OSError:
                    pass
            try:
                conn.close()
            except OSError:
                pass


class LabTelnetServer:
    """Authentic RFC 854 Telnet server with IAC negotiation and realistic terminal echo."""

    # Telnet IAC bytes
    IAC = 255
    WILL = 251
    WONT = 252
    DO = 253
    DONT = 254
    OPT_ECHO = 1
    OPT_SGA = 3
    OPT_TTYPE = 24

    def __init__(self, host: str, port: int):
        self.host = host
        self.port = port
        self._stop = threading.Event()
        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None

    def start(self):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((self.host, self.port))
        self._sock.listen(8)
        self._sock.settimeout(0.5)
        self._thread = threading.Thread(target=self._serve, daemon=True, name="lab-telnet")
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._sock:
            try:
                self._sock.close()
            except OSError:
                pass

    def _serve(self):
        while not self._stop.is_set():
            try:
                conn, _ = self._sock.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self._handle_client, args=(conn,), daemon=True).start()

    def _read_line(self, conn: socket.socket, echo: bool) -> str:
        chars = []
        i = 0
        while not self._stop.is_set():
            data = conn.recv(256)
            if not data:
                break
            idx = 0
            while idx < len(data):
                b = data[idx]
                if b == self.IAC and idx + 2 < len(data):
                    idx += 3  # Skip 3-byte IAC negotiation response
                    continue
                if b == 13:  # \r
                    idx += 1
                    continue
                if b == 10:  # \n
                    if echo:
                        conn.sendall(b"\r\n")
                    return "".join(chars)
                if 32 <= b <= 126:
                    ch = chr(b)
                    chars.append(ch)
                    if echo:
                        conn.sendall(bytes([b]))
                idx += 1
            i += 1
        return "".join(chars)

    def _handle_client(self, conn: socket.socket):
        try:
            conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            conn.settimeout(6.0)
            # Send authentic RFC 854 IAC option negotiation
            iac_init = bytes(
                [
                    self.IAC, self.DO, self.OPT_TTYPE,
                    self.IAC, self.WILL, self.OPT_ECHO,
                    self.IAC, self.WILL, self.OPT_SGA,
                ]
            )
            conn.sendall(iac_init)
            time.sleep(0.03)
            conn.sendall(b"Lab-Router-OS 4.2 (ttyS0)\r\n\r\nlab-router login: ")
            username = self._read_line(conn, echo=True)
            conn.sendall(b"Password: ")
            _password = self._read_line(conn, echo=False)
            conn.sendall(b"\r\nLast login: Mon Nov 16 10:15:00 from 127.0.0.1\r\n")
            conn.sendall(f"Welcome {username}! (Telnet session is UNENCRYPTED)\r\n".encode())
            conn.sendall(f"{username}@lab-router:~$ ".encode())

            for _ in range(5):
                cmd = self._read_line(conn, echo=True).strip()
                if not cmd or cmd == "exit" or cmd == "logout":
                    conn.sendall(b"logout\r\nConnection closed by foreign host.\r\n")
                    break
                elif cmd == "whoami":
                    conn.sendall(f"{username}\r\n".encode())
                elif "lab-secret" in cmd:
                    conn.sendall(SHELL_SECRET_OUTPUT.replace("\n", "\r\n").encode())
                else:
                    conn.sendall(f"Executed: {cmd}\r\n".encode())
                conn.sendall(f"{username}@lab-router:~$ ".encode())
        except Exception:
            pass
        finally:
            try:
                conn.close()
            except OSError:
                pass


class LabUDPServer:
    """Real connectionless UDP server demonstrating 8-byte UDP header vs TCP handshake."""

    def __init__(self, host: str, port: int):
        self.host = host
        self.port = port
        self._stop = threading.Event()
        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None

    def start(self):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((self.host, self.port))
        self._sock.settimeout(0.5)
        self._thread = threading.Thread(target=self._serve, daemon=True, name="lab-udp")
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._sock:
            try:
                self._sock.close()
            except OSError:
                pass

    def _serve(self):
        while not self._stop.is_set():
            try:
                data, addr = self._sock.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                break
            text = data.decode("utf-8", errors="replace").strip()
            user = "unknown"
            for tok in text.split():
                if tok.startswith("user="):
                    user = tok.split("=", 1)[1]
            reply = f"AUTH_OK user={user} session=udp_tok_7741 transport=UDP_CLEARTEXT".encode("utf-8")
            self._sock.sendto(reply, addr)


def _build_ssh_server_classes():
    import paramiko

    class _LabSSHInterface(paramiko.ServerInterface):
        def __init__(self):
            self.event = threading.Event()
            self.exec_command: Optional[str] = None
            self.username: str = "lab_user"

        def check_channel_request(self, kind, chanid):
            if kind == "session":
                return paramiko.OPEN_SUCCEEDED
            return paramiko.OPEN_FAILED_ADMINISTRATIVELY_PROHIBITED

        def check_auth_password(self, username, password):
            self.username = username
            return paramiko.AUTH_SUCCESSFUL

        def get_allowed_auths(self, username):
            return "password"

        def check_channel_exec_request(self, channel, command):
            self.exec_command = command.decode("utf-8", errors="replace")
            self.event.set()
            return True

    class _VirtualSFTPHandle(paramiko.SFTPHandle):
        def __init__(self, data: bytes):
            super().__init__(0)
            self._buf = io.BytesIO(data)

        def read(self, offset, length):
            self._buf.seek(offset)
            return self._buf.read(length)

        def stat(self):
            attr = paramiko.SFTPAttributes()
            attr.st_size = len(self._buf.getvalue())
            attr.st_mode = stat.S_IFREG | 0o644
            return attr

    class _LabSFTPServerInterface(paramiko.SFTPServerInterface):
        def list_folder(self, path):
            attr = paramiko.SFTPAttributes()
            attr.filename = "confidential.txt"
            attr.st_size = len(CONFIDENTIAL_FILE_CONTENT)
            attr.st_mode = stat.S_IFREG | 0o644
            attr.st_mtime = int(time.time())
            return [attr]

        def stat(self, path):
            attr = paramiko.SFTPAttributes()
            if path.endswith("confidential.txt"):
                attr.st_size = len(CONFIDENTIAL_FILE_CONTENT)
                attr.st_mode = stat.S_IFREG | 0o644
            else:
                attr.st_size = 4096
                attr.st_mode = stat.S_IFDIR | 0o755
            return attr

        def lstat(self, path):
            return self.stat(path)

        def open(self, path, flags, attr):
            if "confidential.txt" in path:
                return _VirtualSFTPHandle(CONFIDENTIAL_FILE_CONTENT)
            return paramiko.SFTP_NO_SUCH_FILE

    return paramiko, _LabSSHInterface, _LabSFTPServerInterface


class LabSSHServer:
    """Real RFC 4251-4254 SSH-2.0 server supporting encrypted exec & SFTP v3 subsystem."""

    def __init__(self, host: str, port: int, banner: str, enable_sftp: bool = False):
        self.host = host
        self.port = port
        self.banner = banner
        self.enable_sftp = enable_sftp
        self._stop = threading.Event()
        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self.available = False

    def start(self):
        try:
            self._paramiko, self._iface_cls, self._sftp_cls = _build_ssh_server_classes()
            key_path = ensure_ssh_host_key()
            self._host_key = self._paramiko.RSAKey(filename=str(key_path))
            self.available = True
        except Exception:
            self.available = False
            return

        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((self.host, self.port))
        self._sock.listen(8)
        self._sock.settimeout(0.5)
        self._thread = threading.Thread(
            target=self._serve, daemon=True, name=f"lab-{'sftp' if self.enable_sftp else 'ssh'}"
        )
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._sock:
            try:
                self._sock.close()
            except OSError:
                pass

    def _serve(self):
        while not self._stop.is_set():
            try:
                conn, _ = self._sock.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self._handle_client, args=(conn,), daemon=True).start()

    def _handle_client(self, conn: socket.socket):
        transport = None
        try:
            transport = self._paramiko.Transport(conn)
            transport.local_version = self.banner
            transport.add_server_key(self._host_key)
            if self.enable_sftp:
                transport.set_subsystem_handler("sftp", self._paramiko.SFTPServer, self._sftp_cls)

            server_iface = self._iface_cls()
            transport.start_server(server=server_iface)

            if self.enable_sftp:
                # Let SFTP subsystem handle the channel lifecycle until client disconnects
                deadline = time.time() + 10.0
                while transport.is_active() and time.time() < deadline:
                    time.sleep(0.05)
                return

            chan = transport.accept(5.0)
            if chan is None:
                return
            server_iface.event.wait(3.0)
            cmd = server_iface.exec_command or "whoami"
            output = f"{server_iface.username}\n"
            if "lab-secret" in cmd:
                output += SHELL_SECRET_OUTPUT
            chan.sendall(output.encode("utf-8"))
            chan.send_exit_status(0)
            chan.close()
            time.sleep(0.1)
        except Exception:
            pass
        finally:
            if transport:
                try:
                    transport.close()
                except Exception:
                    pass
            try:
                conn.close()
            except OSError:
                pass


class LabServerManager:
    """Starts and manages all 7 loopback lab servers cleanly."""

    def __init__(self):
        self.http_server: Optional[_ReusableHTTPServer] = None
        self.https_server: Optional[_ReusableHTTPServer] = None
        self.ftp_server: Optional[LabFTPServer] = None
        self.telnet_server: Optional[LabTelnetServer] = None
        self.ssh_server: Optional[LabSSHServer] = None
        self.sftp_server: Optional[LabSSHServer] = None
        self.udp_server: Optional[LabUDPServer] = None
        self.running = False

    def start_all(self) -> dict[str, bool]:
        if self.running:
            return self.status()

        # 1. HTTP
        self.http_server = _ReusableHTTPServer((LOOPBACK_HOST, PORTS["http"]), _make_http_handler("HTTP"))
        threading.Thread(target=self.http_server.serve_forever, daemon=True, name="lab-http").start()

        # 2. HTTPS (real TLS)
        cert_path, key_path = ensure_tls_cert()
        self.https_server = _ReusableHTTPServer((LOOPBACK_HOST, PORTS["https"]), _make_http_handler("HTTPS"))
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(certfile=str(cert_path), keyfile=str(key_path))
        self.https_server.socket = ctx.wrap_socket(self.https_server.socket, server_side=True)
        threading.Thread(target=self.https_server.serve_forever, daemon=True, name="lab-https").start()

        # 3. FTP
        self.ftp_server = LabFTPServer(LOOPBACK_HOST, PORTS["ftp"], PORTS["ftp_data"])
        self.ftp_server.start()

        # 4. Telnet
        self.telnet_server = LabTelnetServer(LOOPBACK_HOST, PORTS["telnet"])
        self.telnet_server.start()

        # 5. SSH
        self.ssh_server = LabSSHServer(
            LOOPBACK_HOST, PORTS["ssh"], banner="SSH-2.0-LabSSH_OpenSSH_9.6", enable_sftp=False
        )
        self.ssh_server.start()

        # 6. SFTP
        self.sftp_server = LabSSHServer(
            LOOPBACK_HOST, PORTS["sftp"], banner="SSH-2.0-LabSFTP_OpenSSH_9.6", enable_sftp=True
        )
        self.sftp_server.start()

        # 7. UDP
        self.udp_server = LabUDPServer(LOOPBACK_HOST, PORTS["udp_demo"])
        self.udp_server.start()

        self.running = True
        return self.status()

    def status(self) -> dict[str, bool]:
        return {
            "http": self.http_server is not None,
            "https": self.https_server is not None,
            "ftp": self.ftp_server is not None,
            "telnet": self.telnet_server is not None,
            "ssh": bool(self.ssh_server and self.ssh_server.available),
            "sftp": bool(self.sftp_server and self.sftp_server.available),
            "udp_demo": self.udp_server is not None,
        }

    def stop_all(self):
        for srv in (self.http_server, self.https_server):
            if srv:
                try:
                    srv.shutdown()
                    srv.server_close()
                except Exception:
                    pass
        for srv in (self.ftp_server, self.telnet_server, self.ssh_server, self.sftp_server, self.udp_server):
            if srv:
                srv.stop()
        self.running = False
