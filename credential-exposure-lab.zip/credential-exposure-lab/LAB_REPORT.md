# Experiment 4: Plaintext Credential Exposure Study
**Course Topic:** Wireshark / `tcpdump`, TCP & UDP  
**Scope:** Local loopback (`127.0.0.1` / `lo`) comparison of plaintext logins (**HTTP, FTP, Telnet, UDP**) vs. encrypted logins (**HTTPS, SFTP, SSH**) — demonstrating exactly what a passive network attacker can observe in each case.

---

## 1. Aim
To deploy local lab servers for plaintext protocols (**HTTP, FTP, Telnet**, plus connectionless **UDP**) and their encrypted counterparts (**HTTPS/TLS 1.3, SFTP, SSH-2.0**), capture genuine wire packets on loopback (`lo`) using `tcpdump`, analyze the resulting Wireshark-compatible `.pcap` files, and document:
1. Exactly what credentials, session tokens, commands, and files a passive network sniffer can extract.
2. What metadata **still remains visible** even when encryption (TLS 1.3 / SSH-2.0) is enabled.
3. How stateful **TCP** (3-way handshake, sequence/acknowledgment stream reassembly) contrasts with connectionless **UDP** (8-byte header, single-datagram exchange).

---

## 2. Lab Topology & Apparatus

All services run locally on `127.0.0.1` inside the isolated lab workspace using dummy test credentials (`username=lab_alice`, `password=CampusLab#2026`). No external hosts are targeted.

| Protocol | Category | Transport | Lab Port | Std Port | Capture File | `tcpdump` BPF Filter |
| :--- | :--- | :---: | :---: | :---: | :--- | :--- |
| **HTTP** | Plaintext | TCP | `18080` | `80` | `captures/http.pcap` | `tcp port 18080` |
| **HTTPS** | Encrypted (TLS 1.3) | TCP | `18443` | `443` | `captures/https.pcap` | `tcp port 18443` |
| **FTP** | Plaintext (RFC 959) | TCP | `12121` / `12122` | `21` | `captures/ftp.pcap` | `tcp port 12121 or tcp port 12122` |
| **SFTP** | Encrypted (SSH-2.0 v3) | TCP | `12223` | `22` | `captures/sftp.pcap` | `tcp port 12223` |
| **Telnet** | Plaintext (RFC 854) | TCP | `12323` | `23` | `captures/telnet.pcap` | `tcp port 12323` |
| **SSH** | Encrypted (SSH-2.0) | TCP | `12222` | `22` | `captures/ssh.pcap` | `tcp port 12222` |
| **UDP Auth/Syslog** | Plaintext (UDP Demo) | UDP | `15140` | `514` | `captures/udp_demo.pcap` | `udp port 15140` |

**Tools Used:**
- `tcpdump 4.99.5` (`--immediate-mode -U -n -s 0 -w captures/<proto>.pcap`)
- OpenSSL 3.x (self-signed RSA-2048 X.509 certificate for `CN=lab-portal.local` with SAN `DNS:lab-portal.local,IP:127.0.0.1`)
- Python 3 (`http.server`, `ssl`, `ftplib`, `socket`, `paramiko` for authentic RFC 4251–4254 SSH-2.0 & SFTP v3)
- Custom Wireshark-compatible `.pcap` dissector & interactive Web Workbench (`web_app.py`)

---

## 3. Observed Results (Real Captured `.pcap` Evidence)

| Protocol | L4 | Packets | Wire Bytes | Payload Entropy | Password in `.pcap`? | Attacker Verdict |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| **HTTP** | TCP | 26 | 3,269 B | **5.38 bits/B** | **YES** (Form + Base64) | **EXPOSED (CRITICAL)** |
| **HTTPS** | TCP | 14 | 6,774 B | **7.95 bits/B** | **NO** (Ciphertext) | **PROTECTED (SECURE)** |
| **FTP** | TCP | 34 | 3,466 B | **5.50 bits/B** | **YES** (`PASS` cmd) | **EXPOSED (CRITICAL)** |
| **SFTP** | TCP | 49 | 11,743 B | **7.94 bits/B** | **NO** (Ciphertext) | **PROTECTED (SECURE)** |
| **Telnet** | TCP | 142 | 12,170 B | **5.45 bits/B** | **YES** (1-char stream) | **EXPOSED (CRITICAL)** |
| **SSH** | TCP | 30 | 8,552 B | **7.74 bits/B** | **NO** (Ciphertext) | **PROTECTED (SECURE)** |
| **UDP Auth/Syslog** | UDP | 2 | 317 B | **5.20 bits/B** | **YES** (Frame #1) | **EXPOSED (CRITICAL)** |

---

## 4. Detailed Protocol-by-Protocol Attacker View

### 4.1 Web Login: HTTP vs. HTTPS
- **HTTP (`captures/http.pcap`) — CRITICAL EXPOSURE:**
  - **Frame #6 (`POST /login` form body):**
    ```text
    username=lab_alice&password=CampusLab%232026&remember=1
    ```
  - **Frame #8 (`200 OK` response header — Session Hijacking Risk):**
    ```text
    Set-Cookie: lab_session=sess_http_plain_8f7a6c5d; Path=/; HttpOnly
    ```
  - **Frame #17 (`GET /api/profile` — Base64 is Encoding, NOT Encryption):**
    ```text
    Authorization: Basic bGFiX2FsaWNlOkNhbXB1c0xhYiMyMDI2
    ==> Base64 Decoded in <1ms: lab_alice:CampusLab#2026
    ```
- **HTTPS (`captures/https.pcap`) — PROTECTED:**
  - TLS 1.3 handshake completes with `TLS_AES_256_GCM_SHA384`. All HTTP requests, form credentials, Basic Auth headers, URL paths, and cookies travel inside TLS `Application Data` records (Shannon entropy **7.95 / 8.00 bits/byte**).
  - **Metadata still visible to attacker:** Source/Dest IP & TCP ports, packet timing/sizes, TLS `ClientHello` **SNI (`lab-portal.local`)**, and negotiated TLS version/cipher suite.

### 4.2 File Transfer: FTP vs. SFTP
- **FTP (`captures/ftp.pcap`) — CRITICAL EXPOSURE:**
  - Control channel (`TCP:12121`) leaks authentication verbatim:
    ```text
    Frame #6 : USER lab_alice
    Frame #9 : PASS CampusLab#2026
    Frame #10: 230 User lab_alice logged in successfully.
    ```
  - Separate passive data channel (`TCP:12122`) leaks the entire downloaded file in cleartext:
    ```text
    Frame #22: === EXP 4 CONFIDENTIAL LAB DOCUMENT ===
               Secret-Token: LAB-FILE-TOKEN-9942-XYZ
    ```
- **SFTP (`captures/sftp.pcap`) — PROTECTED:**
  - Runs as an SFTP v3 subsystem over a single encrypted SSH-2.0 TCP connection (`TCP:12223`) using hybrid post-quantum/elliptic-curve KEX (`mlkem768x25519-sha256` / `curve25519-sha256`).
  - Zero usernames, passwords, directory listings, or file contents appear in plaintext (ciphertext entropy **7.94 / 8.00 bits/byte**).
  - **Metadata still visible to attacker:** Plaintext SSH banners (`SSH-2.0-paramiko_5.1.0` & `SSH-2.0-LabSFTP_OpenSSH_9.6`) and `SSH_MSG_KEXINIT` algorithm lists before `SSH_MSG_NEWKEYS`.

### 4.3 Remote Shell: Telnet vs. SSH
- **Telnet (`captures/telnet.pcap`) — CRITICAL EXPOSURE (142 Packets!):**
  - RFC 854 IAC option negotiation (`IAC DO TERMINAL-TYPE`, `IAC WILL ECHO`, `IAC WILL SUPPRESS-GO-AHEAD`) followed by interactive character-by-character transmission (1 byte per TCP `[PSH, ACK]` packet).
  - Even though the Telnet server **does not echo** the password back to the user's screen, every single character travels client → server in cleartext. Wireshark's **Follow TCP Stream** reassembles:
    - Login: `lab_alice`
    - Password: `CampusLab#2026`
    - Shell commands: `whoami`, `cat /etc/lab-secret.txt`, `exit`
    - Command output: `LAB_SECRET_FLAG=EXP4_NETWORK_SECURITY_2026`
- **SSH (`captures/ssh.pcap`) — PROTECTED:**
  - After banner exchange, `SSH_MSG_KEXINIT`, key exchange, and `SSH_MSG_NEWKEYS`, all `ssh-userauth` credentials, shell commands, and stdout are completely encrypted (ciphertext entropy **7.74 / 8.00 bits/byte**).

### 4.4 Transport Comparison: TCP vs. UDP (`captures/udp_demo.pcap`)
- **TCP (HTTP, HTTPS, FTP, SFTP, Telnet, SSH):** Connection-oriented 20–60 byte header requiring a 3-way handshake (`SYN` → `SYN-ACK` → `ACK`), sequence/acknowledgment tracking, flow control window, and 4-way teardown (`FIN-ACK`), generating **14 to 142 packets** per login session.
- **UDP (`captures/udp_demo.pcap`):** Connectionless fixed **8-byte header** (Src Port, Dst Port, Length, Checksum) with **zero handshake**. The entire exchange finishes in **2 packets**, immediately leaking credentials in Frame #1:
  ```text
  Frame #1 (127.0.0.1:47893 -> 127.0.0.1:15140, UDP len 110):
    AUTH_REQ user=lab_alice pass=CampusLab#2026 host=lab-workstation proto=UDP/15140 notice=NO_HANDSHAKE_CLEARTEXT
  Frame #2 (127.0.0.1:15140 -> 127.0.0.1:47893, UDP len 67):
    AUTH_OK user=lab_alice session=udp_tok_7741 transport=UDP_CLEARTEXT
  ```

---

## 5. Wireshark & `tcpdump` Commands Reference

```bash
# Inspect captured pcaps from CLI
tcpdump -nn -A -r captures/http.pcap
tcpdump -nn -A -r captures/ftp.pcap
tcpdump -nn -A -r captures/telnet.pcap
tcpdump -nn -X -r captures/https.pcap
tcpdump -nn -X -r captures/ssh.pcap
tcpdump -nn -X -r captures/sftp.pcap
tcpdump -nn -A -r captures/udp_demo.pcap
```

| Protocol | Useful Wireshark Display Filters |
| :--- | :--- |
| HTTP | `http.request.method == "POST" \|\| http.authorization \|\| http.set_cookie` |
| HTTPS | `tls.handshake.type == 1 \|\| tls.app_data` |
| FTP | `ftp.request.command == "USER" \|\| ftp.request.command == "PASS" \|\| ftp-data` |
| Telnet | `telnet.data` (then right-click → **Follow → TCP Stream**) |
| SSH / SFTP | `ssh.protocol \|\| ssh.message_code == 20` |
| UDP | `udp.port == 15140` |

---

## 6. Conclusion & Recommended Mitigations
1. **Never rely on plaintext protocols or simple encoding (Base64 / URL-encoding)** for authentication or sensitive data.
2. **Enforce HTTPS (TLS 1.3)** with HSTS and `Secure; HttpOnly; SameSite` cookies to protect credentials and session tokens.
3. **Decommission FTP and Telnet completely**; migrate to **SFTP** and **SSH-2.0** (preferring Ed25519 key-based authentication over passwords).
4. **Encrypt UDP workloads** with DTLS, QUIC, WireGuard, or IPsec rather than transmitting credentials in raw UDP datagrams.
5. **Account for metadata leakage:** Encryption hides payloads, not IPs, ports, traffic sizes, TLS SNI (unless ECH is used), or SSH software banners.
