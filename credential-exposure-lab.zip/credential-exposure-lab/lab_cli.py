#!/usr/bin/env python3
"""
Exp 4 — Plaintext Credential Exposure Study (CLI Runner)
Starts local loopback servers (HTTP, FTP, Telnet, HTTPS, SFTP, SSH + UDP),
captures real loopback traffic into Wireshark-compatible .pcap files using tcpdump,
and prints what a passive network attacker can see in each case.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from lab.analyzer import analyze_protocol_pcap
from lab.capture import capture_protocol_session, detect_capture_capability
from lab.clients import CLIENT_RUNNERS
from lab.config import (
    CAPTURES_DIR,
    DEFAULT_PASSWORD,
    DEFAULT_USERNAME,
    PROTOCOL_ORDER,
    PROTOCOLS,
)
from lab.servers import LabServerManager


def run_suite(
    username: str,
    password: str,
    protocols: list[str],
    analyze_only: bool = False,
) -> dict:
    results = {}
    cap_info = detect_capture_capability()

    print("=" * 84)
    print("  EXP 4: PLAINTEXT CREDENTIAL EXPOSURE STUDY  |  Wireshark / tcpdump, TCP & UDP")
    print("=" * 84)
    print(f"  Capture Mode : {cap_info['method']} (live={cap_info['live_capture_available']})")
    print(f"  Test Account : username={username!r}  password={password!r}")
    print(f"  Output Dir   : {CAPTURES_DIR}")
    print("=" * 84)

    mgr = None
    if not analyze_only:
        mgr = LabServerManager()
        statuses = mgr.start_all()
        time.sleep(0.25)
        print("  Lab Servers  :", ", ".join(f"{k.upper()}={'UP' if v else 'OFF'}" for k, v in statuses.items()))
        print("-" * 84)

    try:
        for proto_id in protocols:
            meta = PROTOCOLS[proto_id]
            cap_meta = None
            if not analyze_only:
                print(f"\n[CAPTURE] {meta['name']:15s} ({meta['transport']}:{meta['lab_port']}) -> captures/{meta['pcap_file']}")
                cap_meta = capture_protocol_session(
                    proto_id,
                    lambda p=proto_id: CLIENT_RUNNERS[p](username, password),
                )
                print(f"          Capture OK: {cap_meta['pcap_size_bytes']} bytes ({cap_meta['duration_ms']} ms)")

            report = analyze_protocol_pcap(
                proto_id,
                expected_username=username,
                expected_password=password,
            )
            if cap_meta:
                report["capture_meta"] = cap_meta
            results[proto_id] = report

            av = report["attacker_view"]
            pkt_cnt = report["pcap"].get("summary", {}).get("packet_count", 0)
            ent = av.get("entropy_bits_per_byte", 0.0)
            badge = "EXPOSED!" if av.get("credentials_exposed") else "ENCRYPTED"
            print(f"  [{badge:9s}] Packets: {pkt_cnt:3d} | Entropy: {ent:.2f} bits/B | {av.get('what_attacker_sees_summary', '')}")
            for ex in av.get("extracted", []):
                cred = f"user={ex['username']!r} pass={ex['password']!r} | " if (ex["username"] or ex["password"]) else ""
                print(f"      -> Frame #{ex['frame']} [{ex['type']}]: {cred}{ex['raw_evidence'][:110]}")
            if not av.get("credentials_exposed"):
                for md in av.get("visible_metadata", [])[2:]:
                    print(f"      -> Visible Metadata [{md['item']}]: {md['value'][:100]}")
    finally:
        if mgr:
            mgr.stop_all()

    print("\n" + "=" * 84)
    print("  SUMMARY MATRIX: WHAT AN ATTACKER SEES ON THE WIRE")
    print("=" * 84)
    print(f"  {'Protocol':<15} {'Transport':<9} {'Packets':<8} {'Entropy':<10} {'Password Leaked?':<18} {'Verdict'}")
    print("-" * 84)
    for proto_id in protocols:
        r = results[proto_id]
        meta = PROTOCOLS[proto_id]
        av = r["attacker_view"]
        pkts = r["pcap"].get("summary", {}).get("packet_count", 0)
        ent = f"{av.get('entropy_bits_per_byte', 0.0):.2f} b/B"
        pw_leaked = av.get("raw_secret_check", {}).get("password_found_in_pcap", av.get("credentials_exposed"))
        leaked_str = "YES (PLAINTEXT)" if pw_leaked else "NO (CIPHERTEXT)"
        verdict = "CRITICAL" if av.get("credentials_exposed") else "SECURE"
        print(f"  {meta['name']:<15} {meta['transport']:<9} {pkts:<8} {ent:<10} {leaked_str:<18} {verdict}")
    print("=" * 84)

    CAPTURES_DIR.mkdir(parents=True, exist_ok=True)
    summary_path = CAPTURES_DIR / "latest_summary.json"
    compact = {
        "username_tested": username,
        "protocols": {
            pid: {
                "packet_count": results[pid]["pcap"].get("summary", {}).get("packet_count", 0),
                "total_wire_bytes": results[pid]["pcap"].get("summary", {}).get("total_wire_bytes", 0),
                "verdict": results[pid]["attacker_view"]["verdict"],
                "credentials_exposed": results[pid]["attacker_view"]["credentials_exposed"],
                "entropy_bits_per_byte": results[pid]["attacker_view"]["entropy_bits_per_byte"],
                "extracted": results[pid]["attacker_view"]["extracted"],
                "visible_metadata": results[pid]["attacker_view"]["visible_metadata"],
                "raw_secret_check": results[pid]["attacker_view"].get("raw_secret_check", {}),
            }
            for pid in protocols
        },
    }
    summary_path.write_text(json.dumps(compact, indent=2))
    print(f"\nSaved summary -> {summary_path}")
    print("Open any file in captures/*.pcap with Wireshark or run `tcpdump -nn -X -r captures/http.pcap`!")
    return results


def main():
    parser = argparse.ArgumentParser(description="Exp 4: Plaintext Credential Exposure Lab CLI")
    parser.add_argument("--username", default=DEFAULT_USERNAME, help="Dummy lab username to test")
    parser.add_argument("--password", default=DEFAULT_PASSWORD, help="Dummy lab password to test")
    parser.add_argument(
        "--only",
        nargs="+",
        choices=PROTOCOL_ORDER,
        default=PROTOCOL_ORDER,
        help="Capture only specified protocols",
    )
    parser.add_argument(
        "--analyze-only",
        action="store_true",
        help="Skip live capture and analyze existing captures/*.pcap files",
    )
    args = parser.parse_args()
    run_suite(args.username, args.password, args.only, analyze_only=args.analyze_only)


if __name__ == "__main__":
    main()
