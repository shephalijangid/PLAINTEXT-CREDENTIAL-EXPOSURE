# Plaintext Credential Exposure Study (Exp 4 — Wireshark / tcpdump, TCP & UDP)

A working, self-contained local network security mini-project that runs **7 real loopback servers** (`HTTP`, `HTTPS`, `FTP`, `SFTP`, `Telnet`, `SSH`, and `UDP`), captures genuine wire packets off `lo` using `tcpdump` into **Wireshark-compatible `.pcap` files**, and provides both a **Wireshark-style interactive Web Workbench** and a **CLI lab runner** showing exactly what a passive attacker can (and cannot) see.

## What Makes This Project Actually Work
- **Real Protocol Servers & Clients on `127.0.0.1`:**
  - **HTTP (`:18080`)**: Real `POST /login` form submission + `GET /api/profile` with `Authorization: Basic` + `Set-Cookie`.
  - **HTTPS (`:18443`)**: Real TLS 1.3 server with OpenSSL-generated RSA-2048 X.509 cert (`CN=lab-portal.local`, SNI verified).
  - **FTP (`:12121` + PASV `:12122`)**: Genuine RFC 959 FTP server & Python `ftplib` client leaking `USER`/`PASS` and `confidential.txt`.
  - **Telnet (`:12323`)**: Genuine RFC 854 IAC negotiation + realistic 1-character-per-packet keystrokes (including un-echoed password!).
  - **SSH (`:12222`)**: Real RFC 4251–4254 SSH-2.0 server & client (`paramiko`) executing remote shell commands encrypted.
  - **SFTP (`:12223`)**: Real SSH-2.0 + SFTP v3 subsystem downloading `confidential.txt` over a single encrypted tunnel.
  - **UDP Auth/Syslog (`:15140`)**: Real connectionless UDP socket contrasting UDP's 8-byte header & 2-packet exchange against TCP's 3-way handshake.
- **Real Packet Captures (`captures/*.pcap`):** Captured live on interface `lo` via `tcpdump --immediate-mode -U -s 0 -w ...` — open any file directly in Wireshark or `tcpdump -r`.
- **Interactive Wireshark-Style Web Workbench (`web_app.py`):**
  - Enter **any dummy lab username & password** and click **Run Live Capture** to watch real packets get captured and analyzed in real time.
  - 3-pane Wireshark Packet List, L2/L3/L4/L7 Packet Details Tree, and 16-byte Hex + ASCII Dump.
  - **Follow TCP / UDP Stream** viewer, raw `tcpdump` viewer, Shannon Entropy comparison chart (~5.3 vs ~7.95 bits/byte), and printable **Exp 4 Lab Report**.

## Quick Start

### 1. Install Dependencies (Debian/Ubuntu)
```bash
./setup.sh
```
*(Or manually: `sudo apt-get install tcpdump openssl && pip install -r requirements.txt`)*

### 2. Run the Interactive Web Workbench
```bash
python3 web_app.py
```
Open `http://localhost:8080` in your browser.

### 3. Run the CLI Capture & Attacker Report
```bash
# Live capture all 7 protocols with custom dummy test credentials
python3 lab_cli.py --username student01 --password MyLabTest#2026

# Re-analyze existing captures/*.pcap without sudo/tcpdump
python3 lab_cli.py --analyze-only
```

### 4. Open Captures Directly in Wireshark or `tcpdump`
```bash
wireshark captures/http.pcap
tcpdump -nn -A -r captures/ftp.pcap
tcpdump -nn -X -r captures/https.pcap
```

## Project Structure
```text
credential-exposure-lab/
├── web_app.py           # Interactive Wireshark-style web workbench + REST API
├── lab_cli.py           # CLI capture suite & side-by-side summary table
├── LAB_REPORT.md        # Complete Exp 4 Lab Report with captured evidence
├── setup.sh             # One-step dependency installer
├── requirements.txt     # Python dependency (paramiko)
├── lab/
│   ├── config.py        # Ports, BPF filters, Wireshark filter cheatsheet
│   ├── certs.py         # OpenSSL X.509 cert & RSA SSH host key generator
│   ├── servers.py       # All 7 real loopback protocol servers
│   ├── clients.py       # Authentic clients executing logins/transfers
│   ├── capture.py       # Live tcpdump (--immediate-mode) + AF_PACKET engine
│   ├── pcap_parser.py   # Pure-Python libpcap reader & L2-L7 protocol dissector
│   └── analyzer.py      # Passive Attacker View, entropy & metadata auditor
├── captures/            # Genuine Wireshark-compatible .pcap files
├── certs/               # Generated local lab TLS cert & SSH host key
└── static/              # Frontend HTML/CSS/JS (zero external CDN deps)
```

> **Ethics & Safety Notice:** This project is strictly designed for authorized educational study on local loopback (`127.0.0.1` / `lo`) using dummy test accounts. Never capture network traffic or credentials on networks you do not own or have explicit permission to test.
