/* Exp 4 Plaintext Credential Exposure Lab — Interactive Workbench JS */

(() => {
  const state = {
    status: null,
    overview: null,
    selectedProtocol: "http",
    protocolData: {},
    selectedFrameNo: null,
    tcpdumpMode: "brief",
    busy: false,
  };

  function esc(val) {
    return String(val ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function $(id) {
    return document.getElementById(id);
  }

  function setToast(msg, isError = false) {
    const el = $("captureToast");
    if (!el) return;
    el.textContent = msg;
    el.style.color = isError ? "#fb7185" : "#38bdf8";
  }

  async function apiGet(url) {
    const res = await fetch(url, { cache: "no-store" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  }

  async function apiPost(url, payload) {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  }

  /* ---------- Tab & Subtab Navigation ---------- */
  function activateTab(tabName) {
    document.querySelectorAll(".tab").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.tab === tabName);
    });
    document.querySelectorAll(".tab-panel").forEach((panel) => {
      panel.classList.toggle("active", panel.id === `tab-${tabName}`);
    });
    if (tabName === "inspector") {
      loadProtocolDetail(state.selectedProtocol);
    }
  }

  function activateSubtab(subName) {
    document.querySelectorAll(".subtab").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.subtab === subName);
    });
    document.querySelectorAll(".subtab-panel").forEach((panel) => {
      panel.classList.toggle("active", panel.id === `subtab-${subName}`);
    });
  }

  /* ---------- Render Header Status ---------- */
  function renderStatus() {
    if (!state.status) return;
    const cap = state.status.capture_capability;
    const servers = state.status.servers || {};
    const upCount = Object.values(servers).filter(Boolean).length;
    const totalCount = Object.keys(servers).length;

    const capPill = $("captureModePill");
    if (cap.live_capture_available) {
      capPill.className = "pill pill-success";
      capPill.textContent = `LIVE CAPTURE: ${cap.method.toUpperCase()} on lo`;
    } else {
      capPill.className = "pill pill-warn";
      capPill.textContent = "REPLAY MODE (Pre-captured .pcap)";
    }

    const srvPill = $("serverCountPill");
    srvPill.className = upCount === totalCount ? "pill pill-success" : "pill pill-warn";
    srvPill.textContent = `${upCount}/${totalCount} Loopback Servers UP`;

    if (state.status.last_tested) {
      $("usernameInput").value = state.status.last_tested.username || "lab_alice";
      $("passwordInput").value = state.status.last_tested.password || "CampusLab#2026";
    }
  }

  /* ---------- Render Overview Tab ---------- */
  function renderOverview() {
    if (!state.overview) return;
    const { order, pairs, protocols, last_tested } = state.overview;

    let exposedCount = 0;
    let protectedCount = 0;
    let totalPackets = 0;
    let plainEntSum = 0, plainEntCnt = 0;
    let encEntSum = 0, encEntCnt = 0;

    order.forEach((pid) => {
      const item = protocols[pid];
      if (!item || !item.captured) return;
      totalPackets += item.summary.packet_count || 0;
      const ent = item.attacker_view.entropy_bits_per_byte || 0;
      if (item.attacker_view.credentials_exposed) {
        exposedCount++;
        plainEntSum += ent;
        plainEntCnt++;
      } else {
        protectedCount++;
        encEntSum += ent;
        encEntCnt++;
      }
    });

    const avgPlain = plainEntCnt ? (plainEntSum / plainEntCnt).toFixed(2) : "0.00";
    const avgEnc = encEntCnt ? (encEntSum / encEntCnt).toFixed(2) : "0.00";

    $("kpiGrid").innerHTML = `
      <div class="kpi-card danger">
        <div class="kpi-label">Plaintext Protocols Exposed</div>
        <div class="kpi-value" style="color:#fb7185">${exposedCount} / ${order.length}</div>
        <div class="kpi-sub">HTTP, FTP, Telnet &amp; UDP leak passwords directly</div>
      </div>
      <div class="kpi-card success">
        <div class="kpi-label">Encrypted Protocols Protected</div>
        <div class="kpi-value" style="color:#34d399">${protectedCount} / ${order.length}</div>
        <div class="kpi-sub">HTTPS (TLS 1.3), SFTP &amp; SSH (0 secrets leaked)</div>
      </div>
      <div class="kpi-card warn">
        <div class="kpi-label">Entropy Contrast (Plain vs Enc)</div>
        <div class="kpi-value">${avgPlain} vs ${avgEnc}</div>
        <div class="kpi-sub">Shannon bits/byte (max 8.00 = ciphertext)</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Real Captured Packets (.pcap)</div>
        <div class="kpi-value">${totalPackets}</div>
        <div class="kpi-sub">Genuine loopback frames captured via tcpdump</div>
      </div>
    `;

    // Side-by-side comparison pairs
    const pairsHtml = pairs
      .map((pair) => {
        const ins = protocols[pair.insecure];
        const sec = protocols[pair.secure];
        return `
          <div class="pair-card">
            <div class="pair-header">
              <div>
                <div class="pair-title">${esc(pair.title)}</div>
                <div class="pair-usecase">${esc(pair.use_case)}</div>
              </div>
              <span class="badge badge-info">TCP Loopback Lab Pair</span>
            </div>
            <div class="pair-split">
              ${renderPairSide(ins, "insecure")}
              ${renderPairSide(sec, "secure")}
            </div>
          </div>
        `;
      })
      .join("");
    $("pairsGrid").innerHTML = pairsHtml;

    // Entropy chart
    const entHtml = order
      .map((pid) => {
        const item = protocols[pid];
        const ent = item.attacker_view.entropy_bits_per_byte || 0;
        const pct = Math.min(100, (ent / 8.0) * 100).toFixed(1);
        const cls = item.protocol.category === "encrypted" ? "enc" : "plain";
        return `
          <div class="entropy-row">
            <div class="entropy-label">${esc(item.protocol.name)}</div>
            <div class="entropy-track"><div class="entropy-fill ${cls}" style="width:${pct}%"></div></div>
            <div class="entropy-val" style="color:${cls === "enc" ? "#34d399" : "#fb7185"}">${ent.toFixed(2)} b/B</div>
          </div>
        `;
      })
      .join("");
    $("entropyChart").innerHTML = entHtml;

    // UDP highlight card
    const udp = protocols["udp_demo"];
    if (udp) {
      const ex = (udp.attacker_view.extracted || [])[0];
      $("udpHighlight").innerHTML = `
        <p class="muted small" style="margin-top:0">${esc(udp.protocol.summary)}</p>
        <div class="evidence-box leaked">
          <div><strong>Frame #1 (No 3-Way Handshake!):</strong></div>
          <div>${ex ? esc(ex.raw_evidence) : "No capture yet"}</div>
          ${ex && ex.password ? `<div style="margin-top:6px">Extracted &rarr; User: <span class="cred-hl">${esc(ex.username)}</span> &nbsp; Password: <span class="cred-hl">${esc(ex.password)}</span></div>` : ""}
        </div>
        <div class="side-stats">
          <span>Packets: <strong>${udp.summary.packet_count || 0}</strong> (vs 26 HTTP / 142 Telnet)</span>
          <span>UDP Header: <strong>8 bytes</strong></span>
          <span>Entropy: <strong>${(udp.attacker_view.entropy_bits_per_byte || 0).toFixed(2)} b/B</strong></span>
        </div>
        <div class="side-actions">
          <button class="btn btn-sm" onclick="window.__inspectProto('udp_demo')">Inspect UDP Packets &rarr;</button>
          <a class="btn btn-sm" href="/api/pcap/udp_demo">Download udp_demo.pcap</a>
        </div>
      `;
    }

    // Summary Table
    $("lastTestedMeta").textContent = `Last tested account: ${last_tested.username} (${last_tested.updated_at})`;
    const tbody = $("summaryTable").querySelector("tbody");
    tbody.innerHTML = order
      .map((pid) => {
        const it = protocols[pid];
        const p = it.protocol;
        const av = it.attacker_view;
        const badge = av.credentials_exposed
          ? `<span class="badge badge-danger">EXPOSED (CRITICAL)</span>`
          : `<span class="badge badge-success">ENCRYPTED (SECURE)</span>`;
        const portStr = p.data_port ? `${p.lab_port} / ${p.data_port}` : `${p.lab_port}`;
        return `
          <tr>
            <td><strong>${esc(p.name)}</strong><div class="muted small">${esc(p.full_name)}</div></td>
            <td><code>${esc(p.transport)}</code></td>
            <td><code>:${esc(portStr)}</code> <span class="muted small">(std :${p.standard_port})</span></td>
            <td><code>${it.summary.packet_count || 0}</code></td>
            <td><code>${it.summary.total_wire_bytes || 0} B</code></td>
            <td><code>${(av.entropy_bits_per_byte || 0).toFixed(2)} b/B</code></td>
            <td>${badge}</td>
            <td>
              <button class="btn btn-sm" onclick="window.__inspectProto('${p.id}')">Inspect</button>
              <a class="btn btn-sm" href="/api/pcap/${p.id}">.pcap</a>
            </td>
          </tr>
        `;
      })
      .join("");

    renderFilterCheatsheet();
    renderLabReport();
  }

  function renderPairSide(item, sideType) {
    if (!item) return "";
    const p = item.protocol;
    const av = item.attacker_view;
    const isExposed = av.credentials_exposed;

    let evidenceHtml = "";
    if (isExposed) {
      const lines = (av.extracted || [])
        .map((ex) => {
          const creds =
            ex.username || ex.password
              ? `<div><strong>${esc(ex.type)}</strong> (Frame #${ex.frame}): User=<span class="cred-hl">${esc(ex.username)}</span> Pass=<span class="cred-hl">${esc(ex.password)}</span></div>`
              : `<div><strong>${esc(ex.type)}</strong> (Frame #${ex.frame}): <code>${esc(ex.raw_evidence.slice(0, 120))}</code></div>`;
          return creds;
        })
        .join("");
      evidenceHtml = `<div class="evidence-box leaked">${lines}</div>`;
    } else {
      const metas = (av.visible_metadata || [])
        .slice(2)
        .map((m) => `<div>&bull; <span class="meta-hl">${esc(m.item)}:</span> ${esc(m.value)}</div>`)
        .join("");
      evidenceHtml = `
        <div class="evidence-box protected">
          <div style="color:#34d399;font-weight:700;margin-bottom:4px">&#10003; 0 Credentials Found in .pcap (Ciphertext Entropy: ${(av.entropy_bits_per_byte || 0).toFixed(2)}/8.00 b/B)</div>
          <div class="muted small" style="margin-bottom:4px">Plaintext metadata still visible to attacker:</div>
          ${metas || "<div>&bull; Only IP/TCP headers &amp; packet timing visible.</div>"}
        </div>
      `;
    }

    return `
      <div class="pair-side ${sideType}">
        <div class="side-top">
          <div class="side-name">
            <span class="${isExposed ? "dot-red" : "dot-green"}"></span>
            ${esc(p.name)} <code style="font-size:11.5px">TCP:${p.lab_port}</code>
          </div>
          <span class="badge ${isExposed ? "badge-danger" : "badge-success"}">
            ${isExposed ? "PLAINTEXT LEAK" : "ENCRYPTED"}
          </span>
        </div>
        <div class="muted small">${esc(p.summary)}</div>
        ${evidenceHtml}
        <div class="side-stats">
          <span>Packets: <strong>${item.summary.packet_count || 0}</strong></span>
          <span>Wire Bytes: <strong>${item.summary.total_wire_bytes || 0}</strong></span>
          <span>Entropy: <strong>${(av.entropy_bits_per_byte || 0).toFixed(2)} b/B</strong></span>
        </div>
        <div class="side-actions">
          <button class="btn btn-sm" onclick="window.__inspectProto('${p.id}')">Inspect in Wireshark View &rarr;</button>
          <button class="btn btn-sm" onclick="window.__recaptureOne('${p.id}')">Re-Capture</button>
          <a class="btn btn-sm" href="/api/pcap/${p.id}">Download .pcap</a>
        </div>
      </div>
    `;
  }

  /* ---------- Wireshark Inspector Tab ---------- */
  function renderProtoSelector() {
    if (!state.overview) return;
    const { order, protocols } = state.overview;
    $("protoSelector").innerHTML = order
      .map((pid) => {
        const it = protocols[pid];
        const exposed = it.attacker_view.credentials_exposed;
        const active = pid === state.selectedProtocol ? "active" : "";
        return `
          <button class="proto-chip ${active}" onclick="window.__inspectProto('${pid}')">
            <span class="${exposed ? "dot-red" : "dot-green"}"></span>
            <span>${esc(it.protocol.name)}</span>
            <span class="muted small">(${it.summary.packet_count || 0})</span>
          </button>
        `;
      })
      .join("");
  }

  async function loadProtocolDetail(protoId, forceRefresh = false) {
    state.selectedProtocol = protoId;
    renderProtoSelector();
    if (!forceRefresh && state.protocolData[protoId]) {
      renderInspector(state.protocolData[protoId]);
      return;
    }
    try {
      const data = await apiGet(`/api/protocol/${protoId}`);
      state.protocolData[protoId] = data;
      renderInspector(data);
    } catch (err) {
      setToast(`Failed to load ${protoId}: ${err.message}`, true);
    }
  }

  function renderInspector(data) {
    const p = data.protocol;
    const av = data.attacker_view;
    const pkts = data.pcap.packets || [];
    const isExposed = av.credentials_exposed;

    // Build Attacker View Banner
    const artifactsHtml = isExposed
      ? av.extracted
          .map(
            (ex) => `
          <div class="artifact-item">
            <div><strong>Frame #${ex.frame} &mdash; ${esc(ex.type)}</strong></div>
            ${ex.username || ex.password ? `<div style="margin:4px 0">Username: <span class="cred-hl">${esc(ex.username)}</span> &nbsp; Password: <span class="cred-hl">${esc(ex.password)}</span></div>` : ""}
            <div class="muted small" style="font-family:var(--mono);word-break:break-all">${esc(ex.raw_evidence)}</div>
          </div>
        `
          )
          .join("")
      : `
          <div class="evidence-box protected" style="margin:0">
            <div style="color:#34d399;font-weight:700;font-size:13.5px">&#10003; Attack Failed &mdash; Zero Plaintext Credentials Found</div>
            <p class="small" style="margin:6px 0 0;color:#d1fae5">
              ${esc(av.what_attacker_sees_summary)}
            </p>
            <p class="small muted" style="margin:6px 0 0">
              Mitigation Note: ${esc(p.mitigation)}
            </p>
          </div>
        `;

    const metaHtml = (av.visible_metadata || [])
      .map(
        (m) => `
        <div class="meta-item">
          <div><strong class="meta-hl">${esc(m.item)}:</strong> <code>${esc(m.value)}</code></div>
          <div class="muted small">${esc(m.why)}</div>
        </div>
      `
      )
      .join("");

    const check = av.raw_secret_check || {};
    const verifyPills =
      "password_found_in_pcap" in check
        ? `
          <span class="badge ${check.username_found_in_pcap ? "badge-danger" : "badge-success"}">
            Username in .pcap: ${check.username_found_in_pcap ? "YES (EXPOSED)" : "NO"}
          </span>
          <span class="badge ${check.password_found_in_pcap ? "badge-danger" : "badge-success"}">
            Password in .pcap: ${check.password_found_in_pcap ? "YES (EXPOSED)" : "NO"}
          </span>
        `
        : "";

    $("attackerBanner").innerHTML = `
      <div class="card-head">
        <div>
          <h3 style="font-size:16px">${esc(p.name)} &mdash; ${esc(p.full_name)}</h3>
          <div class="muted small">${esc(p.attacker_risk)}</div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
          <span class="badge ${isExposed ? "badge-danger" : "badge-success"}">${esc(av.verdict)}</span>
          <span class="badge badge-info">Entropy: ${(av.entropy_bits_per_byte || 0).toFixed(2)} / 8.00 b/B</span>
          ${verifyPills}
          <button class="btn btn-sm" onclick="window.__recaptureOne('${p.id}')">Re-Capture ${esc(p.name)}</button>
          <a class="btn btn-sm" href="/api/pcap/${p.id}">Download ${esc(p.pcap_file)}</a>
        </div>
      </div>

      <div class="attacker-grid">
        <div>
          <div class="small muted" style="font-weight:700;text-transform:uppercase;margin-bottom:6px">
            ${isExposed ? "What an Attacker Extracts Immediately" : "Attacker Credential Extraction Result"}
          </div>
          ${artifactsHtml}
        </div>
        <div>
          <div class="small muted" style="font-weight:700;text-transform:uppercase;margin-bottom:6px">
            Visible Metadata on the Wire (Always Unencrypted)
          </div>
          ${metaHtml}
        </div>
      </div>

      <div class="cmd-strip">
        <div><strong>tcpdump:</strong> <code>${esc(p.tcpdump_cmd)}</code></div>
        <div><strong>Wireshark Filter:</strong> <code>${esc(p.wireshark_cred_filter)}</code></div>
      </div>
    `;

    // Render packet table, streams, tcpdump output
    renderPacketTable(data);
    renderStreams(data);
    renderTcpdump(data);

    // Auto-select first interesting packet (credential leak -> metadata -> payload -> #1)
    const targetPkt =
      pkts.find((x) => x.leaks_credential) ||
      pkts.find((x) => x.plaintext_metadata) ||
      pkts.find((x) => x.payload_length > 0) ||
      pkts[0];
    if (targetPkt) {
      selectPacket(targetPkt.no);
    }
  }

  function renderPacketTable(data) {
    const pkts = data.pcap.packets || [];
    const query = ($("packetFilterInput").value || "").trim().toLowerCase();
    const exposedOnly = $("exposedOnlyChk").checked;
    const payloadOnly = $("payloadOnlyChk").checked;

    const filtered = pkts.filter((p) => {
      if (exposedOnly && !p.leaks_credential) return false;
      if (payloadOnly && p.payload_length === 0) return false;
      if (query) {
        const hay = `${p.no} ${p.src} ${p.dst} ${p.protocol} ${p.info} ${p.payload_ascii}`.toLowerCase();
        if (!hay.includes(query)) return false;
      }
      return true;
    });

    $("packetCountStatus").textContent = `Showing ${filtered.length} of ${pkts.length} frames`;
    const tbody = $("packetTable").querySelector("tbody");
    tbody.innerHTML = filtered
      .map((p) => {
        const cls = [
          p.leaks_credential ? "row-leak" : p.plaintext_metadata ? "row-meta" : "",
          p.no === state.selectedFrameNo ? "row-selected" : "",
        ]
          .filter(Boolean)
          .join(" ");
        const dirBadge = p.direction === "client->server" ? "C &rarr; S" : "S &rarr; C";
        return `
          <tr class="${cls}" data-frame="${p.no}" onclick="window.__selectPacket(${p.no})">
            <td>${p.no}</td>
            <td>${p.time.toFixed(6)}</td>
            <td>${esc(p.src)}</td>
            <td>${esc(p.dst)}</td>
            <td><strong>${esc(p.protocol)}</strong></td>
            <td>${p.length}</td>
            <td>${dirBadge}</td>
            <td>${esc(p.info)}</td>
          </tr>
        `;
      })
      .join("");
  }

  function selectPacket(frameNo) {
    state.selectedFrameNo = frameNo;
    const data = state.protocolData[state.selectedProtocol];
    if (!data) return;
    const pkt = (data.pcap.packets || []).find((p) => p.no === frameNo);
    if (!pkt) return;

    document.querySelectorAll("#packetTable tbody tr").forEach((tr) => {
      tr.classList.toggle("row-selected", Number(tr.dataset.frame) === frameNo);
    });

    $("selectedFrameBadge").textContent = `Frame #${pkt.no} (${pkt.length} bytes, ${pkt.protocol})`;
    $("selectedHexLen").textContent = `${pkt.length} wire bytes (${pkt.payload_length} app payload bytes)`;

    // Build collapsible L2/L3/L4/L7 tree
    const sections = [
      { title: `Frame ${pkt.no}: ${pkt.length} bytes on wire`, obj: pkt.layers.frame, open: false },
      { title: `Layer 2 — ${pkt.layers.link.type || "Link Layer"}`, obj: pkt.layers.link, open: false },
      { title: `Layer 3 — IPv4 (${pkt.src_ip} -> ${pkt.dst_ip})`, obj: pkt.layers.ip, open: false },
      {
        title: `Layer 4 — ${pkt.transport} (${pkt.src_port} -> ${pkt.dst_port})`,
        obj: pkt.layers.transport,
        open: true,
      },
    ];
    if (pkt.layers.application && Object.keys(pkt.layers.application).length > 0) {
      sections.push({
        title: `Layer 7 — ${pkt.protocol} Application Dissection`,
        obj: pkt.layers.application,
        open: true,
      });
    }

    $("packetDetailsTree").innerHTML = sections
      .map((sec) => {
        const rows = Object.entries(sec.obj)
          .map(([k, v]) => {
            const valStr = typeof v === "object" ? JSON.stringify(v, null, 2) : String(v);
            const hl =
              k === "decoded_basic_auth" || k === "credential_field" || k === "plaintext_file" || k === "body"
                ? 'style="color:#fb7185;font-weight:700"'
                : k === "sni" || k === "banner" || k === "selected_cipher"
                ? 'style="color:#fcd34d;font-weight:700"'
                : "";
            return `<div class="kv-row"><div class="kv-key">${esc(k)}</div><div class="kv-val" ${hl}>${esc(valStr)}</div></div>`;
          })
          .join("");
        return `
          <details class="tree-node" ${sec.open ? "open" : ""}>
            <summary>${esc(sec.title)}</summary>
            <div class="tree-body">${rows}</div>
          </details>
        `;
      })
      .join("");

    // Render Hex + ASCII dump
    const hexRows = (pkt.hex_dump || [])
      .map(
        (r) =>
          `<div class="hex-row"><span class="hex-off">${esc(r.offset)}</span><span class="hex-bytes">${esc(r.hex)}</span><span class="hex-ascii">${esc(r.ascii)}</span></div>`
      )
      .join("");
    $("packetHexDump").innerHTML = hexRows || `<div class="muted">No bytes</div>`;
  }

  function renderStreams(data) {
    const streams = data.pcap.streams || [];
    const isEncrypted = data.protocol.category === "encrypted";
    if (!streams.length) {
      $("streamContent").innerHTML = `<div class="muted">No application stream data captured.</div>`;
      return;
    }

    // For Telnet (1-byte keystrokes), coalesce consecutive same-direction chunks into readable stream blocks
    // while noting how many individual TCP frames carried them!
    const html = streams
      .map((st) => {
        const merged = [];
        for (const ch of st.chunks) {
          const prev = merged[merged.length - 1];
          if (data.protocol.id === "telnet" && prev && prev.direction === ch.direction && !prev.text.endsWith("\n")) {
            prev.text += ch.text;
            prev.frames.push(ch.frame);
            prev.length += ch.length;
          } else {
            merged.push({
              direction: ch.direction,
              frames: [ch.frame],
              length: ch.length,
              text: ch.text,
              hex_preview: ch.hex_preview,
            });
          }
        }

        const chunksHtml = merged
          .map((m) => {
            const cls = m.direction === "client->server" ? "c2s" : "s2c";
            const frameDesc =
              m.frames.length > 1
                ? `Frames #${m.frames[0]}..#${m.frames[m.frames.length - 1]} (${m.frames.length} individual TCP packets!)`
                : `Frame #${m.frames[0]}`;
            const body =
              isEncrypted && !m.text.startsWith("SSH-2.0-")
                ? `[Opaque Binary / Ciphertext — ${m.length} bytes]\nHex: ${m.hex_preview}...\nASCII: ${m.text.slice(0, 120)}`
                : m.text;
            return `
              <div class="stream-chunk ${cls}">
                <div class="stream-meta">${esc(m.direction)} &bull; ${esc(frameDesc)} &bull; ${m.length} bytes</div>
                <div>${esc(body)}</div>
              </div>
            `;
          })
          .join("");

        return `
          <div>
            <div class="small muted" style="margin-bottom:6px">
              Stream <code>${esc(st.stream_id)}</code> &mdash; ${st.chunk_count} payload packets, ${st.total_payload_bytes} application bytes
            </div>
            <div class="stream-block">${chunksHtml}</div>
          </div>
        `;
      })
      .join("");
    $("streamContent").innerHTML = html;
  }

  function renderTcpdump(data) {
    const text = state.tcpdumpMode === "hex" ? data.tcpdump_hex : data.tcpdump_summary;
    $("tcpdumpOutput").textContent =
      text || "tcpdump output unavailable on this host (download .pcap to inspect locally with tcpdump -nn -X -r).";
  }

  /* ---------- TCP vs UDP Cheatsheet ---------- */
  function renderFilterCheatsheet() {
    if (!state.overview) return;
    const { order, protocols } = state.overview;
    const tbody = $("filterCheatsheetTable").querySelector("tbody");
    tbody.innerHTML = order
      .map((pid) => {
        const p = protocols[pid].protocol;
        const lookFor =
          p.category === "plaintext"
            ? p.id === "http"
              ? "POST form body (username/password), Authorization: Basic (Base64), Set-Cookie"
              : p.id === "ftp"
              ? "USER & PASS commands on control port + plaintext file bytes on PASV data port"
              : p.id === "telnet"
              ? "1-character-per-packet keystrokes (Follow TCP Stream reveals un-echoed password!)"
              : "Single 8-byte UDP header datagram leaking user= and pass= with zero handshake"
            : p.id === "https"
            ? "TLS ClientHello SNI & cipher list visible; Application Data is high-entropy ciphertext"
            : "SSH-2.0 banner & KEXINIT visible; all packets after SSH_MSG_NEWKEYS are ciphertext";
        return `
          <tr>
            <td><strong>${esc(p.name)}</strong><div class="muted small">${esc(p.transport)} :${p.lab_port}</div></td>
            <td><code>${esc(p.tcpdump_cmd)}</code></td>
            <td><code>${esc(p.wireshark_cred_filter)}</code></td>
            <td class="small">${esc(lookFor)}</td>
          </tr>
        `;
      })
      .join("");
  }

  /* ---------- Exp 4 Lab Report Tab ---------- */
  function renderLabReport() {
    if (!state.overview) return;
    const { order, protocols, last_tested } = state.overview;
    const rows = order
      .map((pid) => {
        const it = protocols[pid];
        const p = it.protocol;
        const av = it.attacker_view;
        const observed = av.credentials_exposed
          ? (av.extracted || [])
              .map((e) => (e.password ? `${e.type}: user="${e.username}", pass="${e.password}"` : e.type))
              .join("; ")
          : "0 credentials recovered; visible metadata: " +
            (av.visible_metadata || [])
              .slice(2)
              .map((m) => `${m.item} (${m.value})`)
              .join("; ");
        return `
          <tr>
            <td><strong>${esc(p.name)}</strong></td>
            <td>${esc(p.transport)}</td>
            <td>${it.summary.packet_count || 0}</td>
            <td>${(av.entropy_bits_per_byte || 0).toFixed(2)} b/B</td>
            <td><strong>${av.credentials_exposed ? "EXPOSED" : "ENCRYPTED"}</strong></td>
            <td class="small">${esc(observed)}</td>
          </tr>
        `;
      })
      .join("");

    $("labReportContent").innerHTML = `
      <h3>1. Aim &amp; Experiment Objective</h3>
      <p>
        To capture, dissect, and compare authentication traffic over legacy plaintext protocols
        (<strong>HTTP, FTP, Telnet</strong>, plus connectionless <strong>UDP</strong>) against modern encrypted protocols
        (<strong>HTTPS/TLS 1.3, SFTP, SSH-2.0</strong>) in a controlled local loopback lab using <code>tcpdump</code>
        and Wireshark-compatible <code>.pcap</code> packet analysis, demonstrating exactly what a passive network attacker can observe.
      </p>

      <h3>2. Lab Topology &amp; Apparatus</h3>
      <ul>
        <li><strong>Capture Interface:</strong> Linux Loopback (<code>lo</code> / <code>127.0.0.1</code>) using <code>tcpdump --immediate-mode -U -s 0 -w captures/&lt;proto&gt;.pcap</code>.</li>
        <li><strong>Local Lab Servers:</strong> HTTP (<code>:18080</code>), HTTPS/TLS 1.3 (<code>:18443</code>, self-signed RSA-2048 cert for <code>lab-portal.local</code>), RFC 959 FTP (<code>:12121</code> + PASV <code>:12122</code>), RFC 854 Telnet (<code>:12323</code>), SSH-2.0 (<code>:12222</code>), SFTP v3 (<code>:12223</code>), and UDP Auth/Syslog (<code>:15140</code>).</li>
        <li><strong>Test Account Captured:</strong> <code>${esc(last_tested.username)}</code> (dummy lab credentials generated purely on localhost; captured ${esc(last_tested.updated_at)}).</li>
      </ul>

      <h3>3. Live Captured Observation Matrix</h3>
      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Protocol</th>
              <th>L4</th>
              <th>Packets</th>
              <th>Entropy</th>
              <th>Exposure</th>
              <th>Observed on the Wire (Attacker View)</th>
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </div>

      <h3>4. Key Security Findings</h3>
      <ol>
        <li><strong>Encoding &ne; Encryption (HTTP Basic Auth):</strong> Base64 in <code>Authorization: Basic ...</code> is trivially reversible by any passive sniffer in &lt;1ms. Plaintext HTTP also leaks session cookies (enabling session hijacking).</li>
        <li><strong>Dual-Channel Exposure in FTP:</strong> FTP leaks <code>USER</code> and <code>PASS</code> on the TCP control channel AND transfers entire files in cleartext on the separate passive (<code>PASV</code>) data channel. SFTP eliminates both risks inside one encrypted SSH-2.0 tunnel.</li>
        <li><strong>Un-Echoed Passwords Still Leak in Telnet:</strong> Even when a Telnet server suppresses terminal echo at the <code>Password:</code> prompt, every keystroke still travels from client to server in plaintext (1 character per TCP packet) and is trivially reconstructed via Wireshark's <em>Follow TCP Stream</em>.</li>
        <li><strong>Encryption Hides Payloads, Not All Metadata:</strong> In HTTPS, SFTP, and SSH, ciphertext entropy reaches ~7.7&ndash;7.95 bits/byte and zero credentials leak — however, an attacker still sees IP addresses, TCP ports, packet timing/sizes, TLS <code>ClientHello</code> SNI (<code>lab-portal.local</code>), SSH version banners (<code>SSH-2.0-...</code>), and <code>KEXINIT</code> algorithm lists.</li>
        <li><strong>TCP vs UDP Transport Behavior:</strong> All 6 login protocols use stateful TCP (20&ndash;60B header, 3-way handshake, Seq/Ack reassembly, 14&ndash;142 packets). Our UDP demo uses an 8-byte connectionless header with zero handshake — exposing credentials in Frame #1 and finishing in just 2 packets.</li>
      </ol>

      <h3>5. Recommended Countermeasures</h3>
      <ul>
        <li>Replace HTTP with <strong>HTTPS (TLS 1.3)</strong> + HSTS + <code>Secure; HttpOnly; SameSite</code> cookies.</li>
        <li>Disable Telnet and legacy FTP completely; standardize on <strong>SSH-2.0</strong> and <strong>SFTP</strong> with Ed25519 key authentication.</li>
        <li>For UDP-based services (Syslog, RADIUS, telemetry), wrap transport in <strong>DTLS</strong>, <strong>QUIC</strong>, or an encrypted VPN tunnel (WireGuard / IPsec).</li>
      </ul>
    `;
  }

  /* ---------- Live Capture Trigger ---------- */
  async function runLiveCapture(protocol) {
    if (state.busy) return;
    const username = $("usernameInput").value.trim() || "lab_alice";
    const password = $("passwordInput").value.trim() || "CampusLab#2026";

    state.busy = true;
    const btn = $("captureAllBtn");
    btn.disabled = true;
    btn.classList.add("loading");
    setToast(
      protocol === "all"
        ? `Running live tcpdump captures on lo for all 7 protocols as "${username}"...`
        : `Running live tcpdump capture on lo for ${protocol.toUpperCase()} as "${username}"...`
    );

    try {
      const resp = await apiPost("/api/capture", { protocol, username, password });
      state.overview = resp.overview;
      // Clear stale detail cache for updated protocols
      if (protocol === "all") {
        state.protocolData = {};
      } else {
        delete state.protocolData[protocol];
      }
      renderOverview();
      renderProtoSelector();
      const activeInspector = document.querySelector("#tab-inspector.active");
      if (activeInspector) {
        await loadProtocolDetail(protocol === "all" ? state.selectedProtocol : protocol, true);
      }
      const count = Object.keys(resp.results || {}).length;
      setToast(`Captured ${count} live .pcap file(s) with username "${username}"!`);
    } catch (err) {
      setToast(`Capture error: ${err.message}`, true);
    } finally {
      state.busy = false;
      btn.disabled = false;
      btn.classList.remove("loading");
    }
  }

  /* ---------- Global Hooks & Event Wiring ---------- */
  window.__inspectProto = (pid) => {
    state.selectedProtocol = pid;
    activateTab("inspector");
    loadProtocolDetail(pid);
  };

  window.__recaptureOne = (pid) => runLiveCapture(pid);
  window.__selectPacket = (frameNo) => selectPacket(frameNo);

  function bindEvents() {
    document.querySelectorAll(".tab").forEach((btn) => {
      btn.addEventListener("click", () => activateTab(btn.dataset.tab));
    });
    document.querySelectorAll(".subtab").forEach((btn) => {
      btn.addEventListener("click", () => activateSubtab(btn.dataset.subtab));
    });

    $("captureAllBtn").addEventListener("click", () => runLiveCapture("all"));

    $("togglePwBtn").addEventListener("click", () => {
      const inp = $("passwordInput");
      if (inp.type === "text") {
        inp.type = "password";
        $("togglePwBtn").textContent = "Show";
      } else {
        inp.type = "text";
        $("togglePwBtn").textContent = "Hide";
      }
    });

    const rerenderPackets = () => {
      const d = state.protocolData[state.selectedProtocol];
      if (d) renderPacketTable(d);
    };
    $("packetFilterInput").addEventListener("input", rerenderPackets);
    $("exposedOnlyChk").addEventListener("change", rerenderPackets);
    $("payloadOnlyChk").addEventListener("change", rerenderPackets);

    $("tcpdumpBriefBtn").addEventListener("click", () => {
      state.tcpdumpMode = "brief";
      $("tcpdumpBriefBtn").classList.add("active");
      $("tcpdumpHexBtn").classList.remove("active");
      const d = state.protocolData[state.selectedProtocol];
      if (d) renderTcpdump(d);
    });
    $("tcpdumpHexBtn").addEventListener("click", () => {
      state.tcpdumpMode = "hex";
      $("tcpdumpHexBtn").classList.add("active");
      $("tcpdumpBriefBtn").classList.remove("active");
      const d = state.protocolData[state.selectedProtocol];
      if (d) renderTcpdump(d);
    });

    $("printReportBtn").addEventListener("click", () => window.print());
  }

  async function init() {
    bindEvents();
    try {
      const [status, overview] = await Promise.all([apiGet("/api/status"), apiGet("/api/overview")]);
      state.status = status;
      state.overview = overview;
      renderStatus();
      renderOverview();
      renderProtoSelector();
    } catch (err) {
      setToast(`Failed to connect to Lab API: ${err.message}`, true);
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
