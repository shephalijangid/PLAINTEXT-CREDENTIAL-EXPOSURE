#!/usr/bin/env bash
set -euo pipefail

echo "=== Exp 4: Plaintext Credential Exposure Lab Setup ==="
if command -v apt-get >/dev/null 2>&1; then
  echo "[1/2] Installing tcpdump and openssl (Debian/Ubuntu)..."
  sudo apt-get update -qq
  sudo apt-get install -y -qq tcpdump openssl
else
  echo "[1/2] Please ensure tcpdump and openssl are installed via your OS package manager."
fi

echo "[2/2] Installing Python dependency (paramiko)..."
pip install -r requirements.txt

echo "Setup complete! Run:"
echo "  python3 lab_cli.py          # Run CLI capture + attacker report"
echo "  python3 web_app.py          # Start interactive Wireshark web lab on :8080"
